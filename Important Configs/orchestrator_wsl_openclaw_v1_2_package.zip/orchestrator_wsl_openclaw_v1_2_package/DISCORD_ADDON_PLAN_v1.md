# OpenClaw Discord Integration Add-On Plan v1

## What changed in v3

The Discord failure was not caused by Ollama, the model, GPU use, pairing, or Discord DM behavior.

The observed gateway logs showed:

- `channels.discord.enabled=true` existed.
- `commands.ownerAllowFrom=["discord:<id>"]` existed.
- The gateway still started with only six plugins:
  - browser
  - device-pair
  - file-transfer
  - memory-core
  - phone-control
  - talk-voice
- The gateway emitted:
  - `plugins.entries.discord: plugin not installed: discord — install the official external plugin with: openclaw plugins install @openclaw/discord`
- The v2 script also tried to write an extra property under `channels.discord`, which OpenClaw rejected:
  - `channels.discord: invalid config: must NOT have additional properties`

Therefore v3 does three things:

1. Installs the official Discord plugin:
   - `openclaw plugins install @openclaw/discord`

2. Keeps `channels.discord` schema-clean:
   - token
   - enabled
   - groupPolicy
   - no custom `orchestratorMode` under `channels.discord`

3. Strengthens redaction:
   - no unredacted `DISCORD_BOT_TOKEN` in captured environment logs
   - redaction is inline inside shell capture commands, not a shell function lost inside `bash -lc`

## Boundary

This remains an add-on. Do not merge it into the baseline bootstrap yet.

The base installer remains responsible for:

- WSL
- zsh / Powerlevel10k
- Node 24
- Ollama
- GPU checks
- Qwen bounded 4K aliases
- OpenClaw bounded Ollama provider
- Dashboard proof

The Discord add-on is responsible only for:

- official Discord plugin installation
- Discord token env storage
- Discord channel config
- command owner config
- gateway restart
- Discord delivery verification

## Token Safety

Any Discord bot token printed in a terminal, log, file upload, screenshot, or chat transcript should be treated as compromised and reset in Discord Developer Portal.

Use hidden input for the new token. Do not run `echo "$DISCORD_BOT_TOKEN"`.

## Success Criteria

Local configuration success:

- `openclaw plugins install @openclaw/discord` succeeds
- gateway logs mention Discord or include Discord in active plugin/channel startup
- `openclaw config get channels.discord --json` succeeds
- `openclaw config get commands.ownerAllowFrom --json` includes `discord:<owner_id>`
- base model remains `ollama/qwen3.5:9b-4k`
- OpenClaw model list still shows `Ctx 4k`

Discord delivery success:

- DM bot
- bot sends pairing code or response
- if pairing code appears:
  - `openclaw pairing list discord`
  - `openclaw pairing approve discord <CODE>`
- after pairing, bot responds and `ollama ps` shows:
  - `qwen3.5:9b-4k`
  - `100% GPU`
  - `4096`

## Discord Developer Portal Checklist

Still manual:

- Bot token reset after any leak
- Message Content Intent enabled if OpenClaw needs ordinary message text
- Bot invited to server if guild testing
- Basic permissions:
  - View Channels
  - Send Messages
  - Read Message History
- Optional only:
  - Manage Channels
  - Manage Messages
- Avoid Administrator unless explicitly testing broad mode


## v4 Hardening Notes

The fresh test proved Discord can now load and trigger the bounded local model path:

- gateway loaded seven plugins including `discord`
- Discord provider started
- bot probe resolved `@ROC-AI`
- bot generated a pairing code
- post-DM `ollama ps` showed `qwen3.5:9b-4k`, `100% GPU`, `CONTEXT 4096`

The remaining security hardening is the OpenClaw gateway warning:

- `plugins.allow is empty; discovered non-bundled plugins may auto-load`

v4 sets:

```json
"plugins": {
  "allow": ["discord"]
}
```

This makes Discord the only trusted external/non-bundled plugin for this add-on while leaving the bundled gateway plugins available.


## v5 Hardening Notes

The v4 verifier could false-fail because it scanned a broad recent journal window and matched stale historical log lines from before Discord was installed, including:

- `plugin not installed: discord`

v5 changes verifier behavior:

- Determine the current `openclaw-gateway.service` active-start timestamp.
- Only use logs since that active service start for plugin assertions.
- Configure script captures gateway logs since its own restart time.

This prevents stale pre-fix logs from being treated as current failures.


## v6 Hardening Notes

v5 configure failed if the Discord plugin was already installed, because `openclaw plugins install @openclaw/discord` exits nonzero when the plugin already exists.

v6 makes plugin install idempotent:

- install Discord plugin if missing
- if already installed, continue
- if install fails for another reason, try `openclaw plugins update @openclaw/discord`
- if update fails, try `openclaw plugins install @openclaw/discord --force`

v5 verify could still fail from stale `plugins.allow is empty` logs because the gateway had not been restarted after the failed v5 configure. v6 verifies the allowlist from current config and uses a fresh `channels status --probe` boundary for current channel health.


## v7 Hardening Notes

v6 exposed two remaining operational flaws:

1. The configure script only checked the current shell variable for `DISCORD_BOT_TOKEN`.
   If the token existed in the systemd user environment or `~/.openclaw/.env` but not the current shell, v6 prompted again.

2. After a Discord token reset, the gateway can fail with:
   - `Discord API /gateway/bot failed (401)`
   - gateway close `4004`
   - channel `stopped, disconnected`

v7 changes:

- Reuse existing token from:
  1. current shell env
  2. `systemctl --user show-environment`
  3. `~/.openclaw/.env`

- Add:
  - `--refresh-token`

Use `--refresh-token` after resetting the bot token in Discord Developer Portal.

Expected recovery:

```bash
bash ~/configure_openclaw_discord_v1.sh --owner-id <DISCORD_USER_ID> --refresh-token
bash ~/verify_openclaw_discord_v1.sh --owner-id <DISCORD_USER_ID>
```


## v8 Hardening Notes

v7 still had a failure mode at plugin installation. The script attempted to suppress plugin install failures, but the `ERR` trap and `set -e` behavior made the control flow too brittle.

v8 rewrites plugin installation as pure `if command; then ... else ... fi` flow, which is safe under `set -Eeuo pipefail`:

- Try install.
- If plugin already exists, treat that as success.
- Otherwise try update.
- Otherwise try force install.
- Only fail if all three fail.

v8 also logs token length after hidden input without printing the token.


## v9 Hardening Notes

v7/v8 verification proved the important path:

- Discord configured and connected
- Gateway restarted cleanly
- Bounded model surface stayed `ollama/qwen3.5:9b-4k`
- Channel status probe reported `Discord default: enabled, configured, running, connected`
- `plugins.allow` was no longer empty

The v7 verifier falsely failed because it required:

```json
["discord"]
```

but the actual working OpenClaw config reported:

```json
["discord", "ollama"]
```

That is acceptable for this stack because `discord` is the external channel plugin and `ollama` is the local provider surface used by the baseline. v9 therefore requires:

- `plugins.allow` is a list
- `discord` is present
- every entry is one of:
  - `discord`
  - `ollama`

Unknown entries still fail verification.
