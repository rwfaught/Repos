#!/usr/bin/env bash
# configure_openclaw_discord_v1.sh
#
# Standalone Discord add-on for an already-working REDO WSL ORCHESTRATOR baseline.
#
# v3 fixes:
#   - installs the official Discord plugin: @openclaw/discord
#   - removes invalid custom properties under channels.discord
#   - uses shell-neutral hidden token input
#   - strengthens token redaction in captured logs
#
# Usage:
#   export DISCORD_BOT_TOKEN='...'   # optional; otherwise hidden prompt
#   bash configure_openclaw_discord_addon_v3.sh --owner-id <DISCORD_USER_ID>

set -Eeuo pipefail

SCRIPT_NAME="$(basename "$0")"
STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_ROOT="${HOME}/orchestrator_discord_addon_logs"
LOG_DIR="${LOG_ROOT}/${STAMP}"
LOG_FILE="${LOG_DIR}/configure.log"
REPORT_FILE="${LOG_DIR}/REPORT.md"
RED_DIR="${LOG_DIR}/redacted"

mkdir -p "$LOG_DIR" "$RED_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

OWNER_ID=""
TOKEN_ENV="DISCORD_BOT_TOKEN"
SKIP_BASELINE_CHECK=0
NO_RESTART=0
SKIP_PLUGIN_INSTALL=0
REFRESH_TOKEN=0

log() { printf '\n[%s] %s\n' "$SCRIPT_NAME" "$*"; }
warn() { printf '\n[%s] WARNING: %s\n' "$SCRIPT_NAME" "$*" >&2; }
die() {
  printf '\n[%s] ERROR: %s\n' "$SCRIPT_NAME" "$*" >&2
  printf '[%s] Log preserved at: %s\n' "$SCRIPT_NAME" "$LOG_FILE" >&2
  exit 1
}

usage() {
  cat <<'EOF'
Usage:
  bash configure_openclaw_discord_addon_v3.sh --owner-id <DISCORD_USER_ID> [options]

Options:
  --owner-id ID             Required. Discord user ID allowed to run owner commands.
  --token-env NAME          Env var holding bot token. Default: DISCORD_BOT_TOKEN.
  --skip-baseline-check     Skip base OpenClaw/Ollama sanity guard.
  --skip-plugin-install     Do not run openclaw plugins install @openclaw/discord.
  --refresh-token           Force hidden prompt for a new Discord bot token.
  --no-restart              Write config but do not restart gateway.
  --help                    Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --owner-id) OWNER_ID="${2:-}"; shift 2 ;;
    --token-env) TOKEN_ENV="${2:-}"; shift 2 ;;
    --skip-baseline-check) SKIP_BASELINE_CHECK=1; shift ;;
    --skip-plugin-install) SKIP_PLUGIN_INSTALL=1; shift ;;
    --refresh-token) REFRESH_TOKEN=1; shift ;;
    --no-restart) NO_RESTART=1; shift ;;
    --help|-h) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

[[ -n "$OWNER_ID" ]] || { usage; die "--owner-id is required"; }
[[ "$OWNER_ID" =~ ^[0-9]+$ ]] || die "--owner-id should be a numeric Discord user ID"

on_error() {
  local rc=$?
  log "FAILED with exit code $rc"
  log "Log preserved at: $LOG_FILE"
  exit "$rc"
}
trap on_error ERR

require_cmd() { command -v "$1" >/dev/null 2>&1 || die "Required command not found: $1"; }

redact_env_command='sed -E "s/^([^=]*(TOKEN|SECRET|PASSWORD|KEY)[^=]*)=.*/\1=<REDACTED>/I"'

prompt_secret() {
  local prompt="$1"
  local var_name="$2"
  local value=""

  printf "%s" "$prompt"
  stty -echo
  IFS= read -r value
  stty echo
  printf "\n"

  printf -v "$var_name" "%s" "$value"
}

load_existing_secret() {
  local env_name="$1"
  local value=""

  # Prefer the current shell env.
  value="${!env_name:-}"
  if [[ -n "$value" ]]; then
    printf "%s" "$value"
    return 0
  fi

  # Then systemd user environment.
  value="$(systemctl --user show-environment 2>/dev/null | sed -n "s/^${env_name}=//p" | head -n 1 || true)"
  if [[ -n "$value" ]]; then
    printf "%s" "$value"
    return 0
  fi

  # Then the persisted OpenClaw env file.
  if [[ -f "$HOME/.openclaw/.env" ]]; then
    value="$(sed -n "s/^${env_name}=//p" "$HOME/.openclaw/.env" | tail -n 1 || true)"
    if [[ -n "$value" ]]; then
      printf "%s" "$value"
      return 0
    fi
  fi

  return 1
}

redact_file() {
  local src="$1"
  local dst="$2"
  if [[ -f "$src" ]]; then
    sed -E 's/^([^=]*(TOKEN|SECRET|PASSWORD|KEY)[^=]*)=.*/\1=<REDACTED>/I' "$src" > "$dst" || true
  fi
}

run_capture() {
  local label="$1"
  local outfile="$2"
  shift 2
  log "$label"
  {
    echo "## $label"
    echo "## Started: $(date -Iseconds)"
    echo "## Command: $*"
    echo
    "$@"
    rc=$?
    echo
    echo "## Exit code: $rc"
    echo "## Finished: $(date -Iseconds)"
    return "$rc"
  } | tee "$outfile"
}

run_shell_capture() {
  local label="$1"
  local outfile="$2"
  local cmd="$3"
  log "$label"
  {
    echo "## $label"
    echo "## Started: $(date -Iseconds)"
    echo "## Command: $cmd"
    echo
    bash -lc "$cmd"
    rc=$?
    echo
    echo "## Exit code: $rc"
    echo "## Finished: $(date -Iseconds)"
    return "$rc"
  } | tee "$outfile"
}

log "Starting OpenClaw Discord configuration v1"
log "Log file: $LOG_FILE"

require_cmd openclaw
require_cmd systemctl
require_cmd journalctl
require_cmd python3
require_cmd npm
require_cmd node

if [[ "$SKIP_BASELINE_CHECK" != "1" ]]; then
  log "Baseline guard: verifying bounded OpenClaw/Ollama surface"
  run_capture "OpenClaw Ollama model list" "$LOG_DIR/openclaw_models_ollama.before.txt" openclaw models list --provider ollama
  run_capture "OpenClaw default model config" "$LOG_DIR/openclaw_agents_defaults_model.before.json" openclaw config get agents.defaults.model --json
  run_shell_capture "systemd user environment before redacted" "$LOG_DIR/systemd_user_environment.before.txt" \
    "systemctl --user show-environment | grep -E 'OLLAMA|OPENCLAW|DISCORD|CUDA' | sed -E 's/^([^=]*(TOKEN|SECRET|PASSWORD|KEY)[^=]*)=.*/\\1=<REDACTED>/I' || true"

  grep -q 'ollama/qwen3.5:9b-4k' "$LOG_DIR/openclaw_models_ollama.before.txt" || die "Baseline model qwen3.5:9b-4k not found. Run/fix base installer first."
  grep -qiE '\b4k\b|4096' "$LOG_DIR/openclaw_models_ollama.before.txt" || die "OpenClaw model list does not show bounded 4k context."
  grep -q 'OLLAMA_API_KEY=<REDACTED>' "$LOG_DIR/systemd_user_environment.before.txt" || die "OLLAMA_API_KEY missing from systemd user environment."
fi

log "Collecting Discord token"
TOKEN_VALUE=""
if [[ "$REFRESH_TOKEN" == "1" ]]; then
  prompt_secret "Paste NEW Discord bot token for ${TOKEN_ENV}: " TOKEN_VALUE
else
  TOKEN_VALUE="$(load_existing_secret "$TOKEN_ENV" || true)"
  if [[ -n "$TOKEN_VALUE" ]]; then
    log "Using existing ${TOKEN_ENV} from shell/systemd/.openclaw env storage."
  else
    prompt_secret "Paste Discord bot token for ${TOKEN_ENV}: " TOKEN_VALUE
  fi
fi
[[ -n "$TOKEN_VALUE" ]] || die "Discord token is empty. Use --refresh-token and paste a valid current Discord bot token."
log "Token received for $TOKEN_ENV; length=${#TOKEN_VALUE} characters."

log "Persisting Discord token by environment variable name: $TOKEN_ENV"
mkdir -p "$HOME/.openclaw" "$HOME/.config/environment.d"
touch "$HOME/.openclaw/.env"
chmod 600 "$HOME/.openclaw/.env"

tmp="$(mktemp)"
grep -v "^${TOKEN_ENV}=" "$HOME/.openclaw/.env" > "$tmp" 2>/dev/null || true
printf '%s=%s\n' "$TOKEN_ENV" "$TOKEN_VALUE" >> "$tmp"
cat "$tmp" > "$HOME/.openclaw/.env"
rm -f "$tmp"
chmod 600 "$HOME/.openclaw/.env"

cat > "$HOME/.config/environment.d/openclaw-discord.conf" <<EOF
${TOKEN_ENV}=${TOKEN_VALUE}
EOF
chmod 600 "$HOME/.config/environment.d/openclaw-discord.conf"

export "${TOKEN_ENV}=${TOKEN_VALUE}"
systemctl --user import-environment "$TOKEN_ENV" || true
redact_file "$HOME/.openclaw/.env" "$RED_DIR/openclaw.env.redacted"

if [[ "$SKIP_PLUGIN_INSTALL" != "1" ]]; then
  log "Installing official OpenClaw Discord plugin if needed"

  if openclaw plugins install @openclaw/discord > "$LOG_DIR/openclaw_plugins_install_discord.txt" 2>&1; then
    cat "$LOG_DIR/openclaw_plugins_install_discord.txt" || true
    log "Discord plugin install completed."
  else
    PLUGIN_INSTALL_RC=$?
    cat "$LOG_DIR/openclaw_plugins_install_discord.txt" || true

    if grep -qiE 'plugin already exists|already installed|already exists' "$LOG_DIR/openclaw_plugins_install_discord.txt"; then
      log "Discord plugin already exists; continuing idempotently."
    else
      warn "Initial Discord plugin install failed with exit code $PLUGIN_INSTALL_RC; attempting plugin update."

      if openclaw plugins update @openclaw/discord > "$LOG_DIR/openclaw_plugins_update_discord.txt" 2>&1; then
        cat "$LOG_DIR/openclaw_plugins_update_discord.txt" || true
        log "Discord plugin update completed."
      else
        PLUGIN_UPDATE_RC=$?
        cat "$LOG_DIR/openclaw_plugins_update_discord.txt" || true
        warn "Plugin update failed with exit code $PLUGIN_UPDATE_RC; attempting force install."

        if openclaw plugins install @openclaw/discord --force > "$LOG_DIR/openclaw_plugins_install_discord_force.txt" 2>&1; then
          cat "$LOG_DIR/openclaw_plugins_install_discord_force.txt" || true
          log "Discord plugin force install completed."
        else
          cat "$LOG_DIR/openclaw_plugins_install_discord_force.txt" || true
          die "Discord plugin install/update/force-install all failed."
        fi
      fi
    fi
  fi
else
  warn "Skipping official Discord plugin install by request."
fi

log "Writing OpenClaw Discord config"
openclaw config set channels.discord.token \
  --ref-provider default \
  --ref-source env \
  --ref-id "$TOKEN_ENV"

openclaw config set channels.discord.enabled true --strict-json || openclaw config set channels.discord.enabled true
openclaw config set channels.discord.groupPolicy allowlist || true
openclaw config set commands.ownerAllowFrom "[\"discord:${OWNER_ID}\"]" --strict-json

log "Cleaning invalid/custom Discord config properties and ensuring plugin allowlist"
python3 - <<'PY'
import json
from pathlib import Path

p = Path.home() / ".openclaw" / "openclaw.json"
cfg = json.loads(p.read_text())

# Keep channels.discord schema-clean. OpenClaw rejects extra fields here.
channels = cfg.setdefault("channels", {})
discord = channels.setdefault("discord", {})
allowed_discord_keys = {"token", "enabled", "groupPolicy"}
for key in list(discord.keys()):
    if key not in allowed_discord_keys:
        del discord[key]
discord["enabled"] = True
discord.setdefault("groupPolicy", "allowlist")

# If the plugin registry/allowlist exists, ensure Discord is admitted.
plugins = cfg.setdefault("plugins", {})
entries = plugins.setdefault("entries", {})
entries.setdefault("discord", {})
if isinstance(entries["discord"], dict):
    entries["discord"]["enabled"] = True

# Harden external/plugin loading. The gateway warned that plugins.allow was empty.
# In current OpenClaw, the working bounded local stack may include both:
#   - discord: external channel plugin
#   - ollama: local model/provider surface
# Do not require exactly one item; keep the approved minimal allowlist explicit.
plugins["allow"] = ["discord", "ollama"]

p.write_text(json.dumps(cfg, indent=2) + "\n")
print("discord config cleaned; plugin allowlist set to ['discord', 'ollama']")
PY

log "Capturing plugin allowlist after patch"
python3 - <<'PY' | tee "$LOG_DIR/openclaw_plugins_allow.after.txt"
import json
from pathlib import Path
p = Path.home() / ".openclaw" / "openclaw.json"
cfg = json.loads(p.read_text())
print(json.dumps(cfg.get("plugins", {}).get("allow"), indent=2))
PY

log "Validating OpenClaw config after Discord patch"
openclaw config validate 2>&1 | tee "$LOG_DIR/openclaw_config_validate.after.txt" || true

log "Capturing redacted OpenClaw config"
python3 - <<'PY' > "$RED_DIR/openclaw.redacted.json" 2>/dev/null || true
import json, os
p=os.path.expanduser("~/.openclaw/openclaw.json")
data=json.load(open(p))
def redact(x):
    if isinstance(x, dict):
        out={}
        for k,v in x.items():
            if any(s in k.lower() for s in ["token","secret","password","key"]):
                out[k]="<REDACTED>"
            else:
                out[k]=redact(v)
        return out
    if isinstance(x, list):
        return [redact(v) for v in x]
    return x
print(json.dumps(redact(data), indent=2, sort_keys=True))
PY

RESTART_SINCE="$(date '+%Y-%m-%d %H:%M:%S')"
if [[ "$NO_RESTART" != "1" ]]; then
  log "Restarting OpenClaw gateway"
  systemctl --user daemon-reload || true
  systemctl --user restart openclaw-gateway.service
  sleep 8
else
  RESTART_SINCE="$(systemctl --user show openclaw-gateway.service -p ActiveEnterTimestamp --value || date '+%Y-%m-%d %H:%M:%S')"
fi

run_capture "OpenClaw gateway status" "$LOG_DIR/openclaw_gateway_status.after.txt" systemctl --user status openclaw-gateway.service --no-pager
run_shell_capture "OpenClaw gateway journal after Discord config" "$LOG_DIR/openclaw_gateway_journal.after.txt" \
  "journalctl --user -u openclaw-gateway.service --since '$RESTART_SINCE' --no-pager | grep -iE 'discord|gateway|plugin|ready|error|warn|owner|token|pair|channel|unknown|fail|login|connected|intent|unauthorized' || true"
run_shell_capture "systemd user environment after redacted" "$LOG_DIR/systemd_user_environment.after.txt" \
  "systemctl --user show-environment | grep -E 'OLLAMA|OPENCLAW|DISCORD|CUDA' | sed -E 's/^([^=]*(TOKEN|SECRET|PASSWORD|KEY)[^=]*)=.*/\\1=<REDACTED>/I' || true"

log "Post-config assertions"
systemctl --user is-active --quiet openclaw-gateway.service || die "OpenClaw gateway is not active after Discord config."
grep -q "${TOKEN_ENV}=<REDACTED>" "$LOG_DIR/systemd_user_environment.after.txt" || warn "Could not confirm ${TOKEN_ENV} in redacted systemd user environment output."
grep -q 'discord' "$RED_DIR/openclaw.redacted.json" || warn "Could not confirm discord config in redacted OpenClaw config."
grep -q "discord:${OWNER_ID}" "$RED_DIR/openclaw.redacted.json" || warn "Could not confirm ownerAllowFrom in redacted OpenClaw config."
if grep -qi 'plugin not installed: discord' "$LOG_DIR/openclaw_gateway_journal.after.txt" "$LOG_DIR/openclaw_config_validate.after.txt" 2>/dev/null; then
  die "OpenClaw still reports Discord plugin not installed."
fi
if grep -qi 'plugins.allow is empty' "$LOG_DIR/openclaw_gateway_journal.after.txt"; then
  die "plugins.allow is still empty; external plugin allowlist hardening failed."
fi
if ! grep -qi 'discord' "$LOG_DIR/openclaw_gateway_journal.after.txt"; then
  warn "No Discord-specific gateway log lines observed after restart."
fi

log "Writing report"
{
  echo "# OpenClaw Discord Configuration Report v1"
  echo
  echo "Created: $(date -Iseconds)"
  echo "Host: $(hostname)"
  echo "User: $(whoami)"
  echo "Owner: discord:$OWNER_ID"
  echo "Token env var: $TOKEN_ENV"
  echo "Log directory: $LOG_DIR"
  echo
  echo "## Result"
  echo
  echo "- Official Discord plugin install attempted"
  echo "- Token refresh requested: $REFRESH_TOKEN"
  echo "- Discord local OpenClaw config written"
  echo "- Discord token storage: env reference via $TOKEN_ENV"
  echo "- Command owner allowlist: discord:$OWNER_ID"
  echo "- Gateway active after restart: yes"
  echo
  echo "## Next"
  echo
  echo "Run:"
  echo
  echo "  bash verify_openclaw_discord_v1.sh --owner-id $OWNER_ID"
} | tee "$REPORT_FILE"

log "Creating Discord add-on evidence archive"
ARCHIVE="$HOME/orchestrator_discord_config_v1_${STAMP}.tar.gz"
tar -czf "$ARCHIVE" -C "$LOG_ROOT" "$STAMP"

EXPORT_DIR=""
for d in "/mnt/c/Users/${WINUSER:-}" /mnt/c/Users/accou /mnt/c/Users/*; do
  [[ -n "$d" && -d "$d/Downloads" && -w "$d/Downloads" ]] || continue
  case "$d" in *"Default User"*|*"All Users"*|*"Public"*) continue ;; esac
  EXPORT_DIR="$d/Downloads"
  break
done

if [[ -n "$EXPORT_DIR" ]]; then
  cp "$ARCHIVE" "$EXPORT_DIR/" || true
  log "Evidence archive copied to: $EXPORT_DIR/$(basename "$ARCHIVE")"
fi

log "Discord configuration v1 complete"
cat "$REPORT_FILE"
