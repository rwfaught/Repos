# QUICK_START_v1

From PowerShell in this package folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -RunBootstrap
```

Then:

```powershell
wsl -d Orchestrator-Ubuntu-22.04-RC2
```

Inside WSL:

```bash
cd ~
bash ./verify_orchestrator_baseline_v1.sh
```

For Discord:

```bash
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/configure_openclaw_discord_v1.sh ~/
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/verify_openclaw_discord_v1.sh ~/
chmod +x ~/configure_openclaw_discord_v1.sh ~/verify_openclaw_discord_v1.sh

bash ~/configure_openclaw_discord_v1.sh --owner-id 150398348518490112 --refresh-token
bash ~/verify_openclaw_discord_v1.sh --owner-id 150398348518490112
```


## v1.1 verifier patch

The baseline verifier was patched after a clean-room run revealed a false failure. The old verifier searched a wrapped log-capture file whose header contained the words `fail` and `error` inside the recorded grep command. v1.1 captures raw gateway logs separately and performs failure assertions only against the raw log payload. It also stops the model before the dashboard test so the dashboard must reload `qwen3.5:9b-4k`, making the dashboard proof stronger.


## v1.2 Optional model tier

v1.2 keeps the safe baseline default as:

```text
ollama/qwen3.5:9b-4k
```

It adds optional gated model flags:

```powershell
-IncludeReasoningModel
  pulls/tests qwen3:30b-thinking
  creates qwen3:30b-thinking-4k

-IncludeCoderModel
  pulls/tests qwen3-coder:30b
  creates qwen3-coder:30b-4k

-PromoteReasoningModel
  makes ollama/qwen3:30b-thinking-4k the OpenClaw primary after install

-PromoteCoderModel
  makes ollama/qwen3-coder:30b-4k the OpenClaw primary after install
```

Recommended first heavy-model test:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC3" `
  -IncludeReasoningModel `
  -IncludeCoderModel `
  -RunBootstrap
```

Do **not** promote either 30B model on the first clean-room install. First prove that both aliases run at `100% GPU` with `CONTEXT 4096`.

Inside WSL, optional model verifier:

```bash
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_2_package/verify_orchestrator_optional_models_v1.sh ~/
chmod +x ~/verify_orchestrator_optional_models_v1.sh
bash ~/verify_orchestrator_optional_models_v1.sh
```
