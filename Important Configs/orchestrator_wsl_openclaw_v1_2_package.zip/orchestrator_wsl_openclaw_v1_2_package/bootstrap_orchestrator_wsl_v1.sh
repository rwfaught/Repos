#!/usr/bin/env bash
# bootstrap_orchestrator_wsl_v1.sh
#
# REDO WSL ORCHESTRATOR — v1.2 one-shot known-good bootstrap for fresh Ubuntu WSL.
#
# Intended first run:
#   bash bootstrap_orchestrator_wsl_v1.sh --yes
#
# Optional repo restore:
#   bash bootstrap_orchestrator_wsl_v1.sh --yes --archive /mnt/c/Users/accou/Downloads/projects.tar.gz
#
# Design:
#   - No reliance on old WSL state.
#   - System Node 24, not nvm, so OpenClaw's systemd gateway is stable.
#   - Handles WSL's NVIDIA shim path: /usr/lib/wsl/lib/nvidia-smi.
#   - Installs Ollama before OpenClaw.
#   - Pulls core local model pack before OpenClaw model config, with optional gated reasoning/coder models.
#   - Configures OpenClaw primary/fallback model schema correctly.
#   - Leaves a timestamped build log and evidence archive.

set -Eeuo pipefail

SCRIPT_NAME="$(basename "$0")"
STAMP="$(date +%Y%m%d_%H%M%S)"
LOG_ROOT="${HOME}/orchestrator_bootstrap_logs"
LOG_DIR="${LOG_ROOT}/${STAMP}"
LOG_FILE="${LOG_DIR}/bootstrap.log"
SUMMARY_FILE="${LOG_DIR}/SUMMARY.md"
RED_DIR="${LOG_DIR}/redacted"

mkdir -p "$LOG_DIR" "$RED_DIR"
exec > >(tee -a "$LOG_FILE") 2>&1

YES=0
ARCHIVE_PATH=""
MODEL_PACK="core"
SKIP_MODELS=0
SKIP_OLLAMA=0
SKIP_OPENCLAW=0
VERIFY_MODELS=1
VERIFY_TIER="safe"
INCLUDE_HEAVY_MODELS=0
INCLUDE_REASONING_MODEL=0
INCLUDE_CODER_MODEL=0
PROMOTE_REASONING_MODEL=0
PROMOTE_CODER_MODEL=0
INCLUDE_RISKY_MODELS=0
CREATE_LOW_CTX_ALIASES=1
WITH_DISCORD=0
DISCORD_OWNER_ID="${DISCORD_OWNER_ID:-}"
DISCORD_TOKEN_ENV="${DISCORD_TOKEN_ENV:-DISCORD_BOT_TOKEN}"
CODE_DIR="${HOME}/codex"
PROJECT_DIR="${CODE_DIR}/projects"

OPENCLAW_PRIMARY="ollama/qwen3.5:9b-4k"
OPENCLAW_FALLBACKS='["ollama/qwen3.5:4b-4k","ollama/qwen3.5:2b-4k","ollama/qwen3:0.6b-4k"]'

log() {
  printf '\n[%s] %s\n' "$SCRIPT_NAME" "$*"
}

die() {
  printf '\n[%s] ERROR: %s\n' "$SCRIPT_NAME" "$*" >&2
  printf '[%s] Log preserved at: %s\n' "$SCRIPT_NAME" "$LOG_FILE" >&2
  exit 1
}

usage() {
  cat <<'EOF'
Usage:
  bash bootstrap_orchestrator_wsl_v1.sh [options]

Options:
  --yes                         Assume yes for non-secret prompts and model pulls.
  --archive PATH                Restore Orchestrator repo from a tar.gz archive.
  --model-pack core|minimal     Default: core.
  --skip-models                 Do not pull Ollama models.
  --skip-ollama                 Do not install/configure Ollama.
  --skip-openclaw               Do not install/configure OpenClaw.
  --no-verify-models            Skip per-model Ollama GPU verification.
  --verify-tier safe|medium|all Model verification tier. Default: medium.
  --include-reasoning-model    Pull/test qwen3:30b-thinking and create qwen3:30b-thinking-4k. Off by default.
  --include-coder-model        Pull/test qwen3-coder:30b and create qwen3-coder:30b-4k. Off by default.
  --promote-reasoning-model    Make ollama/qwen3:30b-thinking-4k the OpenClaw primary after gated install.
  --promote-coder-model        Make ollama/qwen3-coder:30b-4k the OpenClaw primary after gated install.
  --include-heavy-models       Backward-compatible alias for --include-reasoning-model.
  --include-risky-models       Pull/test known-risky large models. Off by default and not recommended.
  --no-low-ctx-aliases          Do not create 4K-context aliases for large models.
  --with-discord                Configure Discord token env-ref and optional owner.
  --discord-owner-id ID         Set commands.ownerAllowFrom to ["discord:ID"].
  --discord-token-env NAME      Env var name for Discord token. Default: DISCORD_BOT_TOKEN.
  --primary MODEL               OpenClaw primary model. Default: ollama/qwen3.5:9b-4k.
  --help                        Show this help.
EOF
}

ask_yes_no() {
  local prompt="$1"
  local default="${2:-n}"
  if [[ "$YES" == "1" ]]; then
    return 0
  fi
  local suffix="[y/N]"
  [[ "$default" == "y" ]] && suffix="[Y/n]"
  read -r -p "$prompt $suffix " ans || true
  ans="${ans:-$default}"
  [[ "$ans" =~ ^[Yy]$ ]]
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --yes) YES=1; shift ;;
    --archive) ARCHIVE_PATH="${2:-}"; [[ -n "$ARCHIVE_PATH" ]] || die "--archive requires path"; shift 2 ;;
    --model-pack) MODEL_PACK="${2:-}"; [[ "$MODEL_PACK" == "core" || "$MODEL_PACK" == "minimal" ]] || die "--model-pack must be core or minimal"; shift 2 ;;
    --skip-models) SKIP_MODELS=1; shift ;;
    --skip-ollama) SKIP_OLLAMA=1; shift ;;
    --skip-openclaw) SKIP_OPENCLAW=1; shift ;;
    --no-verify-models) VERIFY_MODELS=0; shift ;;
    --verify-tier) VERIFY_TIER="${2:-}"; [[ "$VERIFY_TIER" == "safe" || "$VERIFY_TIER" == "medium" || "$VERIFY_TIER" == "all" ]] || die "--verify-tier must be safe, medium, or all"; shift 2 ;;
    --include-reasoning-model) INCLUDE_REASONING_MODEL=1; INCLUDE_HEAVY_MODELS=1; shift ;;
    --include-coder-model) INCLUDE_CODER_MODEL=1; shift ;;
    --promote-reasoning-model) INCLUDE_REASONING_MODEL=1; INCLUDE_HEAVY_MODELS=1; PROMOTE_REASONING_MODEL=1; OPENCLAW_PRIMARY="ollama/qwen3:30b-thinking-4k"; OPENCLAW_FALLBACKS='["ollama/qwen3.5:9b-4k","ollama/qwen3.5:4b-4k","ollama/qwen3.5:2b-4k","ollama/qwen3:0.6b-4k"]'; shift ;;
    --promote-coder-model) INCLUDE_CODER_MODEL=1; PROMOTE_CODER_MODEL=1; OPENCLAW_PRIMARY="ollama/qwen3-coder:30b-4k"; OPENCLAW_FALLBACKS='["ollama/qwen3.5:9b-4k","ollama/qwen3.5:4b-4k","ollama/qwen3.5:2b-4k","ollama/qwen3:0.6b-4k"]'; shift ;;
    --include-heavy-models) INCLUDE_HEAVY_MODELS=1; INCLUDE_REASONING_MODEL=1; shift ;;
    --include-risky-models) INCLUDE_RISKY_MODELS=1; shift ;;
    --no-low-ctx-aliases) CREATE_LOW_CTX_ALIASES=0; shift ;;
    --with-discord) WITH_DISCORD=1; shift ;;
    --discord-owner-id) DISCORD_OWNER_ID="${2:-}"; [[ -n "$DISCORD_OWNER_ID" ]] || die "--discord-owner-id requires value"; shift 2 ;;
    --discord-token-env) DISCORD_TOKEN_ENV="${2:-}"; [[ -n "$DISCORD_TOKEN_ENV" ]] || die "--discord-token-env requires value"; shift 2 ;;
    --primary) OPENCLAW_PRIMARY="${2:-}"; [[ -n "$OPENCLAW_PRIMARY" ]] || die "--primary requires model"; shift 2 ;;
    --help|-h) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
done

on_error() {
  local rc=$?
  log "FAILED with exit code $rc"
  log "Log preserved at: $LOG_FILE"
  exit "$rc"
}
trap on_error ERR

log "Starting v1 one-shot bootstrap"
log "Log file: $LOG_FILE"

log "Checking sudo mode near the start"
cat <<'EOF'
The script will first try passwordless sudo. If that is unavailable,
it will ask for your Linux password once and keep sudo alive during the run.
EOF

SUDO_KEEPALIVE_PID=""
if sudo -n true 2>/dev/null; then
  log "Passwordless sudo is active for this user."
else
  log "Passwordless sudo is not active; prompting once for sudo credentials."
  sudo -v
  # Keep sudo alive while this script runs. This avoids timeout during multi-hour model pulls.
  ( while true; do sudo -n true 2>/dev/null || exit; sleep 60; done ) &
  SUDO_KEEPALIVE_PID=$!
fi

trap 'if [[ -n "${SUDO_KEEPALIVE_PID:-}" ]]; then kill "$SUDO_KEEPALIVE_PID" 2>/dev/null || true; fi' EXIT

# WSL GPU utilities live here. Add this immediately before any checks.
if [[ -d /usr/lib/wsl/lib ]]; then
  export PATH="/usr/lib/wsl/lib:$PATH"
fi

# Prefer Linux tooling over inherited Windows PATH shims.
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/lib/wsl/lib:${HOME}/bin:${HOME}/.local/bin:$PATH"

if [[ "$(id -u)" == "0" ]]; then
  die "Run as normal Linux user, not root."
fi

if ! grep -qi microsoft /proc/version 2>/dev/null; then
  log "This does not look like WSL. Continuing anyway."
fi

log "Checking systemd"
if command -v systemctl >/dev/null 2>&1 && systemctl is-system-running >/dev/null 2>&1; then
  log "systemd is active."
else
  log "systemd is not active. Enabling it in /etc/wsl.conf."
  sudo tee /etc/wsl.conf >/dev/null <<'EOF'
[boot]
systemd=true
EOF
  cat <<EOF

systemd was enabled for future WSL launches.

From POWERSHELL, not inside WSL, run:
  wsl --shutdown

Then reopen Ubuntu and rerun:
  bash ${HOME}/${SCRIPT_NAME} --yes

EOF
  exit 20
fi

log "Installing base Ubuntu packages"
sudo apt-get -o Acquire::Retries=5 update
sudo DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=5 install -y \
  ca-certificates curl wget git git-lfs gnupg software-properties-common \
  build-essential make cmake ninja-build pkg-config \
  python3 python3-dev python3-venv python3-pip pipx \
  jq ripgrep fd-find bat tree htop btop unzip zip tar xz-utils zstd rsync \
  nano vim tmux zsh fonts-font-awesome pciutils openssl lsb-release

log "Persisting WSL GPU shim path for future shells"
if ! grep -q 'REDO_WSL_ORCHESTRATOR_WSL_GPU_PATH' "$HOME/.profile" 2>/dev/null; then
  cat >> "$HOME/.profile" <<'EOF'

# REDO_WSL_ORCHESTRATOR_WSL_GPU_PATH
if [ -d /usr/lib/wsl/lib ]; then
  export PATH="/usr/lib/wsl/lib:$PATH"
fi
EOF
fi

log "Installing zsh, Oh My Zsh, Powerlevel10k, and plugins"
if [[ ! -d "$HOME/.oh-my-zsh" ]]; then
  RUNZSH=no CHSH=no KEEP_ZSHRC=yes sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
fi

ZSH_CUSTOM="${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}"
mkdir -p "$ZSH_CUSTOM/themes" "$ZSH_CUSTOM/plugins"

[[ -d "$ZSH_CUSTOM/themes/powerlevel10k" ]] || git clone --depth=1 https://github.com/romkatv/powerlevel10k.git "$ZSH_CUSTOM/themes/powerlevel10k"
[[ -d "$ZSH_CUSTOM/plugins/zsh-autosuggestions" ]] || git clone --depth=1 https://github.com/zsh-users/zsh-autosuggestions "$ZSH_CUSTOM/plugins/zsh-autosuggestions"
[[ -d "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting" ]] || git clone --depth=1 https://github.com/zsh-users/zsh-syntax-highlighting "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting"

touch "$HOME/.zshrc"
if grep -q '^ZSH_THEME=' "$HOME/.zshrc"; then
  sed -i 's|^ZSH_THEME=.*|ZSH_THEME="powerlevel10k/powerlevel10k"|' "$HOME/.zshrc"
else
  echo 'ZSH_THEME="powerlevel10k/powerlevel10k"' >> "$HOME/.zshrc"
fi

if grep -q '^plugins=' "$HOME/.zshrc"; then
  sed -i 's|^plugins=.*|plugins=(git zsh-autosuggestions zsh-syntax-highlighting)|' "$HOME/.zshrc"
else
  echo 'plugins=(git zsh-autosuggestions zsh-syntax-highlighting)' >> "$HOME/.zshrc"
fi

if ! grep -q 'REDO_WSL_ORCHESTRATOR_PATH_GUARD' "$HOME/.zshrc"; then
  cat >> "$HOME/.zshrc" <<'EOF'

# REDO_WSL_ORCHESTRATOR_PATH_GUARD
if [ -d /usr/lib/wsl/lib ]; then
  export PATH="/usr/lib/wsl/lib:$PATH"
fi
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$HOME/bin:$HOME/.local/bin:$PATH"
EOF
fi

ZSH_BIN="$(command -v zsh)"
if [[ "$SHELL" != "$ZSH_BIN" ]]; then
  log "Setting zsh as default shell for $USER"
  sudo chsh -s "$ZSH_BIN" "$USER" || log "WARNING: chsh failed. zsh is installed; run: sudo chsh -s $ZSH_BIN $USER"
fi

log "Installing system Node.js 24"
if ! command -v node >/dev/null 2>&1 || ! node --version | grep -q '^v24\.'; then
  curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
  sudo DEBIAN_FRONTEND=noninteractive apt-get -o Acquire::Retries=5 install -y nodejs
fi
hash -r
node --version
npm --version
which -a node npm || true

if [[ "$SKIP_OLLAMA" != "1" ]]; then
  log "Checking NVIDIA GPU visibility inside WSL"
  if ! command -v nvidia-smi >/dev/null 2>&1; then
    if [[ -x /usr/lib/wsl/lib/nvidia-smi ]]; then
      export PATH="/usr/lib/wsl/lib:$PATH"
    fi
  fi

  if ! command -v nvidia-smi >/dev/null 2>&1; then
    cat <<'EOF'

nvidia-smi is not visible inside WSL.

From POWERSHELL, not inside WSL, check:
  nvidia-smi
  wsl --status
  wsl --update
  wsl --shutdown

Then reopen Ubuntu and rerun this script.

Inside WSL, the expected NVIDIA shim is:
  /usr/lib/wsl/lib/nvidia-smi

Do not install a normal Linux NVIDIA display driver inside WSL.
EOF
    die "nvidia-smi not found inside WSL."
  fi

  nvidia-smi
  GPU_ID="$(nvidia-smi -L | sed -n 's/.*UUID: \(GPU-[^)]*\)).*/\1/p' | head -1 || true)"
  [[ -n "$GPU_ID" ]] || GPU_ID="0"
  log "Selected CUDA_VISIBLE_DEVICES for Ollama: $GPU_ID"

  log "Installing Ollama"
  if ! command -v ollama >/dev/null 2>&1; then
    curl -fsSL https://ollama.com/install.sh | sh
  else
    log "Ollama already installed: $(ollama --version || true)"
  fi

  log "Configuring Ollama systemd service for NVIDIA/WSL"
  sudo mkdir -p /etc/systemd/system/ollama.service.d
  sudo tee /etc/systemd/system/ollama.service.d/override.conf >/dev/null <<EOF
[Service]
Environment="PATH=/usr/lib/wsl/lib:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
Environment="CUDA_VISIBLE_DEVICES=${GPU_ID}"
Environment="OLLAMA_HOST=127.0.0.1:11434"
Environment="OLLAMA_KEEP_ALIVE=30m"
Environment="OLLAMA_NUM_PARALLEL=1"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable ollama
  sudo systemctl restart ollama

  log "Waiting for Ollama API"
  for _ in {1..90}; do
    if curl -fsS http://127.0.0.1:11434/api/version >/dev/null 2>&1; then
      break
    fi
    sleep 1
  done
  curl -fsS http://127.0.0.1:11434/api/version || die "Ollama API did not become ready"
  ollama --version

  if [[ "$SKIP_MODELS" != "1" ]]; then
    if [[ "$MODEL_PACK" == "minimal" ]]; then
      MODELS=(qwen3:0.6b qwen3.5:4b qwen3.5:9b)
    else
      # Default core is intentionally safe/stable. OpenClaw uses bounded 4K aliases, not raw model names.
      MODELS=(qwen3:0.6b qwen3.5:2b qwen3.5:4b qwen3.5:9b)
      if [[ "$INCLUDE_REASONING_MODEL" == "1" ]]; then
        MODELS+=(qwen3:30b-thinking)
      fi
      if [[ "$INCLUDE_CODER_MODEL" == "1" ]]; then
        MODELS+=(qwen3-coder:30b)
      fi
      if [[ "$INCLUDE_RISKY_MODELS" == "1" ]]; then
        MODELS+=(qwen2.5-coder:32b qwen3:32b qwen3.6:35b)
      fi
    fi

    log "Models queued for pull: ${MODELS[*]}"
    if ask_yes_no "Pull these Ollama models now? This can download many tens of GB." "n"; then
      for model in "${MODELS[@]}"; do
        log "Pulling Ollama model: $model"
        ollama pull "$model"
      done
    else
      log "Skipping model pulls by user choice."
    fi
  fi

  create_low_ctx_alias() {
    local source_model="$1"
    local alias_model="$2"
    local num_ctx="${3:-4096}"

    if [[ "$CREATE_LOW_CTX_ALIASES" != "1" ]]; then
      return 0
    fi

    if ! ollama list | awk 'NR>1 {print $1}' | grep -qx "$source_model"; then
      log "Skipping low-context alias $alias_model; source model missing: $source_model"
      return 0
    fi

    if ollama list | awk 'NR>1 {print $1}' | grep -qx "$alias_model"; then
      log "Low-context alias already exists: $alias_model"
      return 0
    fi

    local modelfile="$LOG_DIR/Modelfile.${alias_model//[:\/]/_}"
    cat > "$modelfile" <<EOF
FROM $source_model
PARAMETER num_ctx $num_ctx
PARAMETER num_predict 512
EOF
    log "Creating low-context alias: $alias_model FROM $source_model num_ctx=$num_ctx"
    ollama create "$alias_model" -f "$modelfile" || log "WARNING: failed to create alias $alias_model"
  }

  verify_model_gpu() {
    local model="$1"
    local safe_name="${model//[:\/]/_}"
    local out_file="$LOG_DIR/verify_${safe_name}.out.txt"
    local ps_file="$LOG_DIR/verify_${safe_name}.ps.txt"
    local status_file="$LOG_DIR/verify_${safe_name}.status.txt"

    log "Verifying Ollama model GPU usage: $model"
    if ! ollama list | awk 'NR>1 {print $1}' | grep -qx "$model"; then
      echo "missing" > "$status_file"
      log "Skipping $model; not installed."
      return 0
    fi

    # Keep one model loaded at a time.
    ollama stop "$model" >/dev/null 2>&1 || true
    sleep 2

    local run_timeout=90
    local load_wait=10
    if [[ "$model" =~ 30b|32b|35b ]]; then
      run_timeout=180
      load_wait=20
    fi

    timeout "${run_timeout}s" ollama run "$model" "Reply with OK only." > "$out_file" 2>&1 &
    local run_pid=$!

    # Give Ollama time to load model and allocate GPU/CPU.
    sleep "$load_wait"
    ollama ps | tee "$ps_file" || true

    # Do not let a stuck model test block the whole script.
    wait "$run_pid" || true
    ollama stop "$model" >/dev/null 2>&1 || true
    sleep 3

    if grep -qi "$model" "$ps_file" && grep -qi 'GPU' "$ps_file"; then
      echo "gpu" > "$status_file"
      log "GPU observed for $model"
    elif grep -qi "$model" "$ps_file"; then
      echo "loaded_no_gpu_observed" > "$status_file"
      log "WARNING: $model loaded, but GPU was not observed in ollama ps."
    else
      echo "not_observed" > "$status_file"
      log "WARNING: $model was not observed in ollama ps during verification."
    fi
  }

  run_model_verification_suite() {
    if [[ "$VERIFY_MODELS" != "1" ]]; then
      log "Skipping per-model GPU verification by user choice."
      return 0
    fi

    log "Creating bounded 4K aliases before verification"
    create_low_ctx_alias qwen3.5:9b qwen3.5:9b-4k 4096
    create_low_ctx_alias qwen3.5:4b qwen3.5:4b-4k 4096
    create_low_ctx_alias qwen3.5:2b qwen3.5:2b-4k 4096
    create_low_ctx_alias qwen3:0.6b qwen3:0.6b-4k 4096

    if [[ "$INCLUDE_REASONING_MODEL" == "1" ]]; then
      create_low_ctx_alias qwen3:30b-thinking qwen3:30b-thinking-4k 4096
    else
      log "Skipping Qwen3 30B Thinking alias. Use --include-reasoning-model for supervised testing."
    fi

    if [[ "$INCLUDE_CODER_MODEL" == "1" ]]; then
      create_low_ctx_alias qwen3-coder:30b qwen3-coder:30b-4k 4096
    else
      log "Skipping Qwen3 Coder 30B alias. Use --include-coder-model for supervised testing."
    fi

    if [[ "$INCLUDE_RISKY_MODELS" == "1" ]]; then
      create_low_ctx_alias qwen2.5-coder:32b qwen2.5-coder:32b-4k 4096
      create_low_ctx_alias qwen3:32b qwen3:32b-4k 4096
      create_low_ctx_alias qwen3.6:35b qwen3.6:35b-4k 4096
    fi

    local verify_models=(qwen3.5:9b-4k qwen3.5:4b-4k qwen3.5:2b-4k qwen3:0.6b-4k)

    if [[ ("$VERIFY_TIER" == "medium" || "$VERIFY_TIER" == "all") && "$INCLUDE_REASONING_MODEL" == "1" ]]; then
      verify_models+=(qwen3:30b-thinking-4k)
    elif [[ "$VERIFY_TIER" == "medium" || "$VERIFY_TIER" == "all" ]]; then
      log "Reasoning verification tier requested, but --include-reasoning-model was not set. Staying on bounded safe models."
    fi

    if [[ ("$VERIFY_TIER" == "medium" || "$VERIFY_TIER" == "all") && "$INCLUDE_CODER_MODEL" == "1" ]]; then
      verify_models+=(qwen3-coder:30b-4k)
    fi

    if [[ "$VERIFY_TIER" == "all" && "$INCLUDE_RISKY_MODELS" == "1" ]]; then
      verify_models+=(qwen2.5-coder:32b-4k qwen3:32b-4k qwen3.6:35b-4k)
    fi

    log "Model verification tier: $VERIFY_TIER"
    log "Models queued for verification: ${verify_models[*]}"

    for model in "${verify_models[@]}"; do
      verify_model_gpu "$model"
    done

    log "Model verification summary"
    {
      echo "model,status"
      for f in "$LOG_DIR"/verify_*.status.txt; do
        [[ -f "$f" ]] || continue
        base="$(basename "$f" .status.txt)"
        model="${base#verify_}"
        echo "$model,$(cat "$f")"
      done
    } | tee "$LOG_DIR/model_verification_summary.csv"
  }


  log "Ollama model list"
  ollama list || true

  run_model_verification_suite

  log "Running final Ollama GPU smoke test with qwen3:0.6b"
  ollama pull qwen3:0.6b >/dev/null 2>&1 || true
  timeout 90s ollama run qwen3:0.6b "Reply with OK only." >/tmp/orchestrator_ollama_smoke.txt 2>&1 || true
  ollama ps | tee "$LOG_DIR/ollama_ps_after_smoke.txt" || true

  if ollama ps | grep -qi 'GPU'; then
    log "Ollama reports GPU usage."
  else
    log "WARNING: ollama ps did not show GPU usage. Check journalctl -u ollama."
  fi
fi

if [[ "$SKIP_OPENCLAW" != "1" ]]; then
  log "Installing OpenClaw after Ollama/model setup"
  # Do not call plain `sudo -v` here. With mixed sudoers entries, `sudo -v`
  # can still prompt even when command-specific NOPASSWD sudo works.
  # `sudo -n true` is the automation-safe check; it fails instead of prompting.
  if ! sudo -n true 2>/dev/null; then
    log "sudo credential timestamp unavailable before OpenClaw install; prompting once."
    sudo -v
  fi
  sudo -n npm install -g openclaw@latest
  hash -r

  command -v openclaw >/dev/null 2>&1 || die "openclaw command not found after npm install"
  if which openclaw | grep -q '^/mnt/c/'; then
    die "openclaw resolves to Windows npm shim. PATH is wrong: $(which openclaw)"
  fi
  openclaw --version

  log "Persisting OLLAMA_API_KEY=ollama-local for OpenClaw Ollama provider"
  mkdir -p "$HOME/.openclaw" "$HOME/.config/environment.d"
  touch "$HOME/.openclaw/.env"
  if grep -q '^OLLAMA_API_KEY=' "$HOME/.openclaw/.env"; then
    sed -i 's/^OLLAMA_API_KEY=.*/OLLAMA_API_KEY=ollama-local/' "$HOME/.openclaw/.env"
  else
    printf '\nOLLAMA_API_KEY=ollama-local\n' >> "$HOME/.openclaw/.env"
  fi
  cat > "$HOME/.config/environment.d/openclaw-ollama.conf" <<'EOF'
OLLAMA_API_KEY=ollama-local
EOF
  chmod 600 "$HOME/.openclaw/.env" "$HOME/.config/environment.d/openclaw-ollama.conf"
  export OLLAMA_API_KEY=ollama-local
  systemctl --user import-environment OLLAMA_API_KEY || true

  log "Patching OpenClaw explicit Ollama provider config with bounded 4K model contexts"
  export ORCH_INCLUDE_REASONING_MODEL="$INCLUDE_REASONING_MODEL"
  export ORCH_INCLUDE_CODER_MODEL="$INCLUDE_CODER_MODEL"
  export ORCH_PROMOTE_REASONING_MODEL="$PROMOTE_REASONING_MODEL"
  export ORCH_PROMOTE_CODER_MODEL="$PROMOTE_CODER_MODEL"
  python3 - <<'PY'
import json, time, os
from pathlib import Path
p = Path.home() / '.openclaw' / 'openclaw.json'
p.parent.mkdir(parents=True, exist_ok=True)
if p.exists():
    cfg = json.loads(p.read_text())
    backup = p.with_name(f'openclaw.json.before-v8-explicit-ollama.{time.strftime("%Y%m%d_%H%M%S")}.bak')
    backup.write_text(json.dumps(cfg, indent=2) + '\n')
else:
    cfg = {}

cfg.setdefault('models', {})
cfg['models'].setdefault('providers', {})

def model(mid, name, max_tokens=1024, num_predict=512):
    return {
        'id': mid,
        'name': name,
        'reasoning': False,
        'input': ['text'],
        'cost': {'input': 0, 'output': 0, 'cacheRead': 0, 'cacheWrite': 0},
        'contextWindow': 4096,
        'contextTokens': 4096,
        'maxTokens': max_tokens,
        'params': {'num_ctx': 4096, 'num_predict': num_predict, 'temperature': 0.2, 'think': False},
    }

provider_models = [
    model('qwen3.5:9b-4k', 'Qwen 3.5 9B 4K'),
    model('qwen3.5:4b-4k', 'Qwen 3.5 4B 4K'),
    model('qwen3.5:2b-4k', 'Qwen 3.5 2B 4K'),
    model('qwen3:0.6b-4k', 'Qwen 3 0.6B 4K', 512, 256),
]

if os.environ.get('ORCH_INCLUDE_REASONING_MODEL') == '1':
    m = model('qwen3:30b-thinking-4k', 'Qwen 3 30B Thinking 4K', 1024, 512)
    m['reasoning'] = True
    m['params']['think'] = True
    provider_models.append(m)

if os.environ.get('ORCH_INCLUDE_CODER_MODEL') == '1':
    provider_models.append(model('qwen3-coder:30b-4k', 'Qwen 3 Coder 30B 4K', 1024, 512))

cfg['models']['providers']['ollama'] = {
    'baseUrl': 'http://127.0.0.1:11434',
    'apiKey': 'ollama-local',
    'api': 'ollama',
    'contextWindow': 4096,
    'contextTokens': 4096,
    'maxTokens': 1024,
    'timeoutSeconds': 240,
    'models': provider_models,
}

cfg.setdefault('gateway', {})
cfg['gateway']['bind'] = 'loopback'
cfg.setdefault('agents', {})
cfg['agents'].setdefault('defaults', {})
cfg['agents']['defaults']['model'] = {
    'primary': 'ollama/qwen3.5:9b-4k',
    'fallbacks': ['ollama/qwen3.5:4b-4k', 'ollama/qwen3.5:2b-4k', 'ollama/qwen3:0.6b-4k'],
}
p.write_text(json.dumps(cfg, indent=2) + '\n')
print(f'patched {p}')
PY

  log "Configuring OpenClaw default model object"
  MODEL_JSON="{\"primary\":\"${OPENCLAW_PRIMARY}\",\"fallbacks\":${OPENCLAW_FALLBACKS}}"
  openclaw config set agents.defaults.model "$MODEL_JSON" --strict-json
  openclaw config get agents.defaults.model --json | tee "$LOG_DIR/openclaw_model_config.json"

  log "Configuring OpenClaw gateway local mode and token"
  openclaw config set gateway.mode local
  openclaw config set gateway.bind loopback || true

  GATEWAY_TOKEN="${OPENCLAW_GATEWAY_TOKEN:-sk-OPENCLAW-$(openssl rand -hex 32)}"
  openclaw config set gateway.auth.mode token || true
  openclaw config set gateway.auth.token "$GATEWAY_TOKEN" || true

  mkdir -p "$HOME/.openclaw/agents/main/sessions"

  if [[ -n "$DISCORD_OWNER_ID" ]]; then
    log "Configuring OpenClaw command owner for Discord ID: $DISCORD_OWNER_ID"
    openclaw config set commands.ownerAllowFrom "[\"discord:${DISCORD_OWNER_ID}\"]" --strict-json
  fi

  if [[ "$WITH_DISCORD" == "1" ]]; then
    log "Configuring Discord channel token env-ref"
    if [[ -z "${!DISCORD_TOKEN_ENV:-}" ]]; then
      read -rsp "Paste Discord bot token for ${DISCORD_TOKEN_ENV}: " TOKEN_INPUT
      echo
      export "${DISCORD_TOKEN_ENV}=${TOKEN_INPUT}"
    fi

    mkdir -p "$HOME/.openclaw" "$HOME/.config/environment.d"
    umask 077
    printf '%s=%s\n' "$DISCORD_TOKEN_ENV" "${!DISCORD_TOKEN_ENV}" > "$HOME/.openclaw/.env"
    printf '%s=%s\n' "$DISCORD_TOKEN_ENV" "${!DISCORD_TOKEN_ENV}" > "$HOME/.config/environment.d/openclaw-discord.conf"
    chmod 600 "$HOME/.openclaw/.env" "$HOME/.config/environment.d/openclaw-discord.conf"

    openclaw config set channels.discord.token \
      --ref-provider default \
      --ref-source env \
      --ref-id "$DISCORD_TOKEN_ENV"
    openclaw config set channels.discord.enabled true --strict-json
    openclaw config set channels.discord.groupPolicy allowlist || true
    systemctl --user import-environment "$DISCORD_TOKEN_ENV" || true
  fi

  log "Installing and starting OpenClaw gateway service"
  openclaw gateway install --force || openclaw gateway install || true
  sudo loginctl enable-linger "$USER" || true
  systemctl --user daemon-reload
  systemctl --user enable openclaw-gateway.service || true
  systemctl --user restart openclaw-gateway.service

  sleep 5
  systemctl --user status openclaw-gateway.service --no-pager | tee "$LOG_DIR/openclaw_gateway_status.txt" || true
  journalctl --user -u openclaw-gateway.service -n 120 --no-pager | tee "$LOG_DIR/openclaw_gateway_journal_last120.txt" || true

  if systemctl --user is-active --quiet openclaw-gateway.service; then
    log "OpenClaw gateway is active."
  else
    die "OpenClaw gateway did not become active."
  fi
fi

restore_archive() {
  local archive="$1"
  [[ -f "$archive" ]] || die "Archive not found: $archive"

  log "Restoring Orchestrator from archive: $archive"
  mkdir -p "$CODE_DIR"

  local prefix=""
  if tar -tf "$archive" | grep -q '^projects/'; then
    prefix="projects"
  elif tar -tf "$archive" | grep -q '^codex/projects/'; then
    prefix="codex/projects"
  elif tar -tf "$archive" | grep -q '^home/roger/codex/projects/'; then
    prefix="home/roger/codex/projects"
  else
    die "Could not find projects/, codex/projects/, or home/roger/codex/projects/ inside archive."
  fi

  local tmp
  tmp="$(mktemp -d)"
  tar -xzf "$archive" -C "$tmp" "$prefix"

  mkdir -p "$PROJECT_DIR"
  rsync -a --delete \
    --exclude='.venv' \
    --exclude='venv' \
    --exclude='node_modules' \
    --exclude='__pycache__' \
    --exclude='*.pyc' \
    --exclude='*:Zone.Identifier' \
    "$tmp/$prefix/" "$PROJECT_DIR/"

  rm -rf "$tmp"

  find "$PROJECT_DIR" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
  find "$PROJECT_DIR" -name '*.pyc' -delete 2>/dev/null || true
  find "$PROJECT_DIR" -name '*:Zone.Identifier' -delete 2>/dev/null || true

  log "Orchestrator restored to: $PROJECT_DIR"

  if [[ -f "$PROJECT_DIR/main.py" ]]; then
    python3 -m venv "$PROJECT_DIR/.venv"
    # shellcheck disable=SC1091
    source "$PROJECT_DIR/.venv/bin/activate"
    (cd "$PROJECT_DIR" && python main.py --help >/dev/null 2>&1 || true)
    deactivate || true
  fi

  mkdir -p "$HOME/bin"
  cat > "$HOME/bin/orch" <<EOF
#!/usr/bin/env bash
cd "$PROJECT_DIR" || exit 1
if [ -f ".venv/bin/activate" ]; then
  source ".venv/bin/activate"
fi
exec python main.py "\$@"
EOF
  chmod +x "$HOME/bin/orch"
}

if [[ -n "$ARCHIVE_PATH" ]]; then
  restore_archive "$ARCHIVE_PATH"
else
  log "No --archive provided. Skipping Orchestrator restore."
fi

log "Writing redacted OpenClaw config snapshot"
if [[ -f "$HOME/.openclaw/openclaw.json" ]]; then
  python3 - <<'PY' > "$RED_DIR/openclaw.redacted.json" 2>/dev/null || true
import json, os
p=os.path.expanduser("~/.openclaw/openclaw.json")
data=json.load(open(p))
def redact(x):
    if isinstance(x, dict):
        out={}
        for k,v in x.items():
            if any(s in k.lower() for s in ["token","secret","password","key"]):
                out[k]="<REDACTED>"
            else:
                out[k]=redact(v)
        return out
    if isinstance(x, list):
        return [redact(v) for v in x]
    return x
print(json.dumps(redact(data), indent=2, sort_keys=True))
PY
fi

log "Writing summary"
{
  echo "# REDO WSL ORCHESTRATOR v1 one-shot bootstrap summary"
  echo
  echo "Created: $(date -Iseconds)"
  echo "User: $USER"
  echo "Host: $(hostname)"
  echo "Log: $LOG_FILE"
  echo
  echo "## Versions"
  command -v node >/dev/null && echo "node: $(node --version)"
  command -v npm >/dev/null && echo "npm: $(npm --version)"
  command -v openclaw >/dev/null && echo "openclaw: $(openclaw --version)"
  command -v ollama >/dev/null && echo "ollama: $(ollama --version)"
  command -v zsh >/dev/null && echo "zsh: $(zsh --version)"
  echo
  echo "## Evidence"
  echo "- Ollama ps after smoke: $LOG_DIR/ollama_ps_after_smoke.txt"
  echo "- Model verification summary: $LOG_DIR/model_verification_summary.csv"
  echo "- OpenClaw explicit Ollama provider uses contextWindow/contextTokens/num_ctx=4096"
  echo "- OpenClaw gateway status: $LOG_DIR/openclaw_gateway_status.txt"
  echo "- OpenClaw gateway journal: $LOG_DIR/openclaw_gateway_journal_last120.txt"
  echo "- Redacted OpenClaw config: $RED_DIR/openclaw.redacted.json"
  echo
  echo "## Manual items"
  echo "- Close/reopen WSL after completion so zsh becomes the login shell."
  echo "- Windows Terminal font: select MesloLGS NF / Nerd Font for Powerlevel10k."
  echo "- Discord Developer Portal intents are separate if --with-discord is used."
  echo "- qwen3:30b-thinking is opt-in behind --include-reasoning-model and should not be promoted automatically."
  echo "- qwen3-coder:30b is opt-in behind --include-coder-model and should not be promoted automatically."
  echo "- qwen3.6:35b is intentionally excluded unless --include-risky-models is used."
} > "$SUMMARY_FILE"

log "Creating evidence archive"
EVIDENCE_TAR="$HOME/orchestrator_one_shot_bootstrap_${STAMP}.tar.gz"
tar -czf "$EVIDENCE_TAR" -C "$LOG_ROOT" "$STAMP"

EXPORT_DIR=""
for d in /mnt/c/Users/*/Downloads; do
  if [[ -d "$d" && -w "$d" ]]; then
    EXPORT_DIR="$d"
    break
  fi
done

if [[ -n "$EXPORT_DIR" ]]; then
  cp "$EVIDENCE_TAR" "$EXPORT_DIR/" || true
  log "Evidence archive copied to: $EXPORT_DIR/$(basename "$EVIDENCE_TAR")"
fi

log "Completed v1 one-shot bootstrap"
cat "$SUMMARY_FILE"
