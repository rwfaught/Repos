# QUICK_START_v1

From PowerShell in this package folder:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -RunBootstrap
```

Then:

```powershell
wsl -d Orchestrator-Ubuntu-22.04-RC2
```

Inside WSL:

```bash
cd ~
bash ./verify_orchestrator_baseline_v1.sh
```

For Discord:

```bash
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/configure_openclaw_discord_v1.sh ~/
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/verify_openclaw_discord_v1.sh ~/
chmod +x ~/configure_openclaw_discord_v1.sh ~/verify_openclaw_discord_v1.sh

bash ~/configure_openclaw_discord_v1.sh --owner-id 150398348518490112 --refresh-token
bash ~/verify_openclaw_discord_v1.sh --owner-id 150398348518490112
```
