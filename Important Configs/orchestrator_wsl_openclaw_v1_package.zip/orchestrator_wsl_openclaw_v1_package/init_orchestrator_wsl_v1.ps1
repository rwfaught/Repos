# init_orchestrator_wsl_v1.ps1
#
# Creates a fresh, custom-named Ubuntu 22.04 WSL2 distro for testing the
# REDO WSL ORCHESTRATOR one-shot bootstrap script.
#
# This does NOT remove or modify your existing Ubuntu-22.04 distro.
#
# Normal use:
#   powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 -RunBootstrap
#
# Recreate the test distro if it already exists:
#   powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 -ForceRecreate -RunBootstrap
#
# Copy only, do not run bootstrap:
#   powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1
#
# Notes:
#   - Uses wsl --import so the test distro can have a generic/custom name.
#   - Downloads the Ubuntu 22.04 WSL rootfs from Canonical cloud-images.
#   - Creates a Linux user and enables systemd.
#   - Grants temporary passwordless sudo to that user so the bootstrap can run unattended.
#     You can remove this later inside the distro:
#       sudo rm /etc/sudoers.d/90-orchestrator-bootstrap
#
# Requirements:
#   - Windows with WSL installed.
#   - The file bootstrap_orchestrator_wsl_v1.sh must sit next to this PS1 file.

[CmdletBinding()]
param(
    [string]$DistroName = "Orchestrator-Ubuntu-22.04",
    [string]$LinuxUser = "roger",
    [string]$InstallBase = "$env:LOCALAPPDATA\WSL\Orchestrator",
    [string]$CacheDir = "$env:USERPROFILE\Downloads\orchestrator-wsl-cache",
    [switch]$ForceRecreate,
    [switch]$RunBootstrap,
    [switch]$SkipWslUpdate,
    [switch]$KeepRootfsArchive
)

$ErrorActionPreference = "Stop"

$RootfsUrl = "https://cloud-images.ubuntu.com/wsl/jammy/current/ubuntu-jammy-wsl-amd64-ubuntu22.04lts.rootfs.tar.gz"
$Sha256Url = "https://cloud-images.ubuntu.com/wsl/jammy/current/SHA256SUMS"
$RootfsFile = Join-Path $CacheDir "ubuntu-jammy-wsl-amd64-ubuntu22.04lts.rootfs.tar.gz"
$Sha256File = Join-Path $CacheDir "SHA256SUMS"
$InstallLocation = Join-Path $InstallBase $DistroName
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$BootstrapScript = Join-Path $ScriptDir "bootstrap_orchestrator_wsl_v1.sh"

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "[orchestrator-wsl-init] $Message" -ForegroundColor Cyan
}

function Fail {
    param([string]$Message)
    throw "[orchestrator-wsl-init] ERROR: $Message"
}

function Invoke-External {
    param(
        [Parameter(Mandatory=$true)]
        [string]$FilePath,
        [Parameter(ValueFromRemainingArguments=$true)]
        [string[]]$Arguments
    )
    & $FilePath @Arguments
    if ($LASTEXITCODE -ne 0) {
        Fail "Command failed: $FilePath $($Arguments -join ' ')"
    }
}

function Get-WslDistros {
    $raw = & wsl.exe --list --quiet 2>$null
    if ($LASTEXITCODE -ne 0) {
        return @()
    }
    return @($raw | ForEach-Object { ($_ -replace "`0","").Trim() } | Where-Object { $_ })
}

function Convert-WindowsPathToWslPath {
    param([Parameter(Mandatory=$true)][string]$Path)
    $full = (Resolve-Path $Path).Path
    $drive = $full.Substring(0,1).ToLower()
    $rest = $full.Substring(2).Replace("\","/")
    return "/mnt/$drive$rest"
}

function ShellQuote {
    param([string]$s)
    return "'" + ($s -replace "'", "'\''") + "'"
}

function Download-FileWithRetry {
    param(
        [Parameter(Mandatory=$true)][string]$Uri,
        [Parameter(Mandatory=$true)][string]$OutFile,
        [int]$Retries = 3
    )

    for ($i = 1; $i -le $Retries; $i++) {
        try {
            Invoke-WebRequest -Uri $Uri -OutFile $OutFile
            return
        } catch {
            if ($i -eq $Retries) { throw }
            Write-Warning "Download failed on attempt $i/$Retries. Retrying..."
            Start-Sleep -Seconds 3
        }
    }
}


Write-Step "Checking WSL availability"
& wsl.exe --version
if ($LASTEXITCODE -ne 0) {
    Fail "wsl.exe is not available or WSL is not installed."
}

if (-not $SkipWslUpdate) {
    Write-Step "Updating WSL engine from Windows side"
    & wsl.exe --update
    if ($LASTEXITCODE -ne 0) {
        Write-Warning "wsl --update failed or requires elevation. Continuing, but this should be checked manually."
    }
}

Write-Step "Setting default WSL version to 2"
& wsl.exe --set-default-version 2 | Out-Null

if (-not (Test-Path $BootstrapScript)) {
    Fail "Missing bootstrap script beside PS1: $BootstrapScript"
}

$existing = Get-WslDistros
if ($existing -contains $DistroName) {
    if (-not $ForceRecreate) {
        Fail "Distro '$DistroName' already exists. Use -ForceRecreate to unregister only that test distro."
    }

    Write-Step "ForceRecreate enabled. Terminating and unregistering existing test distro: $DistroName"
    & wsl.exe --terminate $DistroName 2>$null | Out-Null
    & wsl.exe --unregister $DistroName
    if ($LASTEXITCODE -ne 0) {
        Fail "Failed to unregister existing test distro: $DistroName"
    }
}

Write-Step "Creating cache folder"
New-Item -ItemType Directory -Force -Path $CacheDir | Out-Null
New-Item -ItemType Directory -Force -Path $InstallBase | Out-Null

Write-Step "Downloading SHA256SUMS"
Download-FileWithRetry -Uri $Sha256Url -OutFile $Sha256File

function Test-RootfsHash {
    param([string]$FilePath)

    if (-not (Test-Path $FilePath)) {
        return $false
    }

    $rootfsName = Split-Path -Leaf $FilePath
    $shaLine = Get-Content $Sha256File | Where-Object { $_ -match [regex]::Escape($rootfsName) } | Select-Object -First 1
    if (-not $shaLine) {
        Fail "Could not find SHA256 entry for $rootfsName in $Sha256File"
    }

    $script:ExpectedRootfsHash = ($shaLine -split "\s+")[0].ToLower()
    $script:ActualRootfsHash = (Get-FileHash -Algorithm SHA256 $FilePath).Hash.ToLower()
    return ($script:ExpectedRootfsHash -eq $script:ActualRootfsHash)
}

Write-Step "Checking cached Ubuntu 22.04 WSL rootfs"
if (Test-Path $RootfsFile) {
    if (Test-RootfsHash -FilePath $RootfsFile) {
        Write-Host "Using verified cached rootfs: $RootfsFile"
        Write-Host "SHA256 verified: $ActualRootfsHash"
    } else {
        Write-Warning "Cached rootfs SHA256 mismatch."
        Write-Warning "Expected $ExpectedRootfsHash but got $ActualRootfsHash"
        Write-Warning "Deleting cached rootfs and downloading a fresh copy."
        Remove-Item -Force $RootfsFile
    }
}

if (-not (Test-Path $RootfsFile)) {
    Write-Step "Downloading Ubuntu 22.04 WSL rootfs"
    Download-FileWithRetry -Uri $RootfsUrl -OutFile $RootfsFile
}

Write-Step "Verifying rootfs SHA256"
if (-not (Test-RootfsHash -FilePath $RootfsFile)) {
    Fail "SHA256 mismatch after fresh download. Expected $ExpectedRootfsHash but got $ActualRootfsHash"
}
Write-Host "SHA256 verified: $ActualRootfsHash"

if (Test-Path $InstallLocation) {
    if ($ForceRecreate) {
        Write-Step "Removing old install directory: $InstallLocation"
        Remove-Item -Recurse -Force $InstallLocation
    } else {
        Fail "Install location already exists: $InstallLocation. Use -ForceRecreate or remove it manually."
    }
}
New-Item -ItemType Directory -Force -Path $InstallLocation | Out-Null

Write-Step "Importing custom-named WSL2 distro: $DistroName"
Invoke-External wsl.exe --import $DistroName $InstallLocation $RootfsFile --version 2

Write-Step "Bootstrapping Linux user, sudo, and systemd"
$setupLinux = @"
set -euo pipefail
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y sudo ca-certificates curl locales
locale-gen en_US.UTF-8 >/dev/null 2>&1 || true

if ! id -u "$LinuxUser" >/dev/null 2>&1; then
  useradd -m -s /bin/bash "$LinuxUser"
fi

usermod -aG sudo "$LinuxUser"

install -d -m 0755 /etc/sudoers.d
cat >/etc/sudoers.d/90-orchestrator-bootstrap <<'EOF'
$LinuxUser ALL=(ALL) NOPASSWD:ALL
EOF
chmod 0440 /etc/sudoers.d/90-orchestrator-bootstrap
visudo -cf /etc/sudoers.d/90-orchestrator-bootstrap

cat >/etc/wsl.conf <<'EOF'
[boot]
systemd=true

[user]
default=$LinuxUser
EOF

mkdir -p /home/$LinuxUser
chown -R ${LinuxUser}:${LinuxUser} /home/$LinuxUser
"@

$encodedSetup = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($setupLinux))
Invoke-External wsl.exe --distribution $DistroName --user root -- bash -lc "echo $encodedSetup | base64 -d | bash"

Write-Step "Terminating distro once so systemd/default user settings apply"
& wsl.exe --terminate $DistroName | Out-Null
Start-Sleep -Seconds 3

Write-Step "Copying v8 bootstrap script into distro"
$wslBootstrapPath = Convert-WindowsPathToWslPath $BootstrapScript
$copyCmd = "cp $(ShellQuote $wslBootstrapPath) /home/$LinuxUser/bootstrap_orchestrator_wsl_v1.sh && chown ${LinuxUser}:${LinuxUser} /home/$LinuxUser/bootstrap_orchestrator_wsl_v1.sh && chmod +x /home/$LinuxUser/bootstrap_orchestrator_wsl_v1.sh"
Invoke-External wsl.exe --distribution $DistroName --user root -- bash -lc $copyCmd

Write-Step "Verifying new distro identity"
Invoke-External wsl.exe --distribution $DistroName --user $LinuxUser -- bash -lc "whoami && cat /etc/os-release | grep PRETTY_NAME && ps -p 1 -o comm="

Write-Step "Verifying passwordless sudo for bootstrap user"
Invoke-External wsl.exe --distribution $DistroName --user root -- bash -lc "visudo -cf /etc/sudoers.d/90-orchestrator-bootstrap && runuser -u $LinuxUser -- sudo -n true && echo NOPASSWD_SUDO_OK"

if ($RunBootstrap) {
    Write-Step "Running v1 bootstrap inside $DistroName. This can take a long time."
    Invoke-External wsl.exe --distribution $DistroName --user $LinuxUser -- bash -lc "cd ~ && bash ./bootstrap_orchestrator_wsl_v1.sh --yes"
} else {
    Write-Step "Bootstrap copied but not run."
    Write-Host ""
    Write-Host "To run it manually:"
    Write-Host "  wsl -d $DistroName"
    Write-Host "  cd ~"
    Write-Host "  bash ./bootstrap_orchestrator_wsl_v1.sh --yes"
}

Write-Step "Current WSL distros"
& wsl.exe --list --verbose

if (-not $KeepRootfsArchive) {
    Write-Step "Rootfs archive kept in cache for reuse: $RootfsFile"
    Write-Host "Use -KeepRootfsArchive to make this message explicit; script does not delete cached rootfs by default."
}

Write-Host ""
Write-Host "Done."
Write-Host "Test distro name: $DistroName"
Write-Host "Install location: $InstallLocation"
Write-Host ""
Write-Host "To enter:"
Write-Host "  wsl -d $DistroName"
