# Next ChatGPT Session Brief — Orchestrator WSL/OpenClaw v1

You are entering a long-running project called **Orchestrator**.

The user is Roger. The project goal is a local-first AI orchestration system: inspectable, bounded, resumable, human-controlled, local by default, with explicit escalation only when needed. The current thread focused on rebuilding Roger's WSL/OpenClaw/Ollama environment into a reproducible install path.

## What we were trying to accomplish

Roger wanted a near one-shot install process that could rebuild a clean WSL environment and get OpenClaw running locally against Ollama with GPU acceleration. The intended end state was:

1. Fresh custom Ubuntu 22.04 WSL2 distro.
2. Stable Linux baseline: packages, zsh, Oh My Zsh, Powerlevel10k.
3. Node 24 and npm installed correctly inside WSL, not accidentally using Windows Node wrappers.
4. Ollama installed under systemd.
5. NVIDIA GPU visible inside WSL.
6. Ollama configured to use GPU rather than falling back to CPU.
7. Safe local model pack installed.
8. OpenClaw installed and configured to use a bounded local Ollama model.
9. Dashboard path verified.
10. Discord bot connected as a command/chat surface.
11. All of this packaged into reproducible scripts.

## What happened

We iterated through several failure points and hardened the scripts.

Major failure points encountered:

- PowerShell `-d` was swallowed by PowerShell's common parameter behavior when calling `wsl.exe` through a function. Fixed by using long flags: `--distribution`, `--user`.

- Ubuntu rootfs cache hash mismatch. Fixed by deleting the bad cached rootfs and re-downloading.

- Imported WSL user did not have a known password. Fixed by creating and validating a passwordless sudo rule in the test distro.

- `sudo -v` caused prompts even after passwordless command sudo worked. Fixed by using `sudo -n true` and `sudo -n <command>` patterns.

- The install accidentally tried to set risky/heavy models as defaults. Policy corrected: use safe bounded `qwen3.5:9b-4k` as the default; keep 30B thinking model behind gated opt-in.

- Some large models hard-locked or crashed the laptop. `qwen3:30b-thinking-4k` was observed working at 100% GPU / 4096 context, but it is still not the default. `qwen3.6:35b` and `qwen3-coder:30b` caused lock/crash symptoms and should not be default.

- OpenClaw Discord config existed but Discord did not load because the official external plugin was not installed. Fixed by installing `@openclaw/discord`.

- Discord token handling was unsafe at first. Later scripts use hidden token input and redaction. If a token is exposed, it must be reset.

- Discord verification falsely failed on stale logs. Later verifier uses fresh probe boundaries.

- Plugin allowlist hardening needed refinement. The final acceptable allowlist is `["discord", "ollama"]`, not strictly `["discord"]`.

## Current working technical state

The working baseline is:

```text
PowerShell init script:
  init_orchestrator_wsl_v1.ps1
  derived from init_orchestrator_wsl_test_distro_v7.ps1

Linux bootstrap:
  bootstrap_orchestrator_wsl_v1.sh
  derived from redo_wsl_orchestrator_one_shot_v8_2.sh

Baseline verifier:
  verify_orchestrator_baseline_v1.sh
  derived from verify_orchestrator_openclaw_ollama_4k.sh

Discord configure:
  configure_openclaw_discord_v1.sh
  derived from configure_openclaw_discord_addon_v9.sh

Discord verifier:
  verify_openclaw_discord_v1.sh
  derived from verify_openclaw_discord_addon_v9.sh
```

The package name created at the end of the prior session was:

```text
orchestrator_wsl_openclaw_v1_package.zip
```

The baseline model policy is:

```text
Default:
  ollama/qwen3.5:9b-4k

Fallbacks:
  ollama/qwen3.5:4b-4k
  ollama/qwen3.5:2b-4k
  ollama/qwen3:0.6b-4k
```

The expected proof lines are:

```text
Model                                      Input      Ctx         Local Auth  Tags
ollama/qwen3.5:9b-4k                       text       4k          yes   yes   default
```

and, from `ollama ps`:

```text
qwen3.5:9b-4k    ...    100% GPU    4096
```

The Discord proof state achieved before packaging was:

```text
Discord default: enabled, configured, running, connected, bot:@ROC-AI, token:config, intents:content=limited, works
plugins.allow approved: ['discord', 'ollama']
```

## What is not solved yet

The bot works as a transport, but it sounds generic. Roger called it "dumb." This is not an infrastructure failure. It is an agent identity/context failure.

The next layer is likely:

```text
OPENCLAW AGENT IDENTITY / ORCHESTRATOR BOOTSTRAP ADD-ON
```

It should configure the OpenClaw active agent workspace files so the bot behaves like Roc, a local Orchestrator command agent, not a generic assistant.

Files to inspect first:

```bash
find ~/.openclaw -maxdepth 5 -type f \
  \( -name 'SOUL.md' -o -name 'AGENTS.md' -o -name 'USER.md' -o -name 'MEMORY.md' -o -name 'TOOLS.md' \) \
  -print

sed -n '1,220p' ~/.openclaw/agents/main/workspace/SOUL.md 2>/dev/null || true
sed -n '1,220p' ~/.openclaw/agents/main/workspace/AGENTS.md 2>/dev/null || true
sed -n '1,220p' ~/.openclaw/agents/main/workspace/USER.md 2>/dev/null || true
sed -n '1,220p' ~/.openclaw/workspace/SOUL.md 2>/dev/null || true
sed -n '1,220p' ~/.openclaw/workspace/AGENTS.md 2>/dev/null || true
```

The identity add-on should probably write or update:

```text
SOUL.md
AGENTS.md
USER.md
TOOLS.md
MEMORY.md, if OpenClaw uses it
```

Target behavior for Roc:

- Knows its name is Roc.
- Knows Roger is the operator.
- Does not call itself a blank slate.
- Does not default to generic warm assistant language.
- Operates as a local-first Orchestrator command agent.
- Is direct, collaborative, bounded, and project-aware.
- Distinguishes normal chat from privileged/local execution.
- Asks before risky action.
- Can summarize current system state.
- Can respect narrow test prompts such as "Reply with OK only."

## Next clean-room test

Before moving to identity, Roger wanted to test a full fresh install from a new PowerShell prompt into a new distro name.

Use a unique distro name:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -RunBootstrap
```

If that name already exists and should be replaced:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -ForceRecreate `
  -RunBootstrap
```

The init script supports `-DistroName`, `-LinuxUser`, `-InstallBase`, `-CacheDir`, `-ForceRecreate`, `-RunBootstrap`, `-SkipWslUpdate`, and `-KeepRootfsArchive`.

It only unregisters the exact distro passed by `-DistroName` if `-ForceRecreate` is used.

## Clean-room test sequence

After the base install completes:

```powershell
wsl -d Orchestrator-Ubuntu-22.04-RC2
```

Inside WSL:

```bash
cd ~
bash ./verify_orchestrator_baseline_v1.sh
```

Then Discord:

```bash
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/configure_openclaw_discord_v1.sh ~/
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/verify_openclaw_discord_v1.sh ~/
chmod +x ~/configure_openclaw_discord_v1.sh ~/verify_openclaw_discord_v1.sh

bash ~/configure_openclaw_discord_v1.sh --owner-id 150398348518490112 --refresh-token
bash ~/verify_openclaw_discord_v1.sh --owner-id 150398348518490112
```

When prompted for a Discord bot token, paste the current valid token from Discord Developer Portal. Do not print it.

## Important caution

Do not suggest using the heavy model as default. The laptop previously hard locked under 35B-class load. The safe default is `qwen3.5:9b-4k`.

Do not assume the Discord token remains valid if it has appeared in chat, screenshots, logs, or pasted text. If exposed, reset it.

Do not merge the Discord add-on into the baseline installer until the clean-room test passes. Keep baseline install and Discord add-on separable.

Do not move to agent identity until the reproducible install path is confirmed, unless Roger explicitly chooses to pause infrastructure and work on behavior.

## Recommended next move for the next session

1. Ask Roger whether the clean install into the new distro completed.
2. If yes, inspect the baseline verifier and Discord verifier results.
3. If both pass, ratify `orchestrator_wsl_openclaw_v1_package` as the current RC.
4. Then start a new add-on: `openclaw_agent_identity_v1`.
5. Draft `SOUL.md`, `AGENTS.md`, `USER.md`, and a verifier that asks Roc identity questions over Discord and checks behavior.

The key frame: **we solved the wire; now we need to shape the mind at the other end of the wire.**
