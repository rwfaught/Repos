# Orchestrator WSL + OpenClaw v1 Package

This package contains the current working release-candidate files renamed as **v1**.

It is designed to test whether a fresh PowerShell prompt can create a new custom Ubuntu 22.04 WSL distro, install the local OpenClaw/Ollama stack, verify the bounded GPU model path, then configure Discord as a command/chat surface.

## Package contents

- `init_orchestrator_wsl_v1.ps1`  
  Windows-side PowerShell init script. Creates/imports a custom-named Ubuntu 22.04 WSL2 distro and optionally runs the Linux bootstrap.

- `bootstrap_orchestrator_wsl_v1.sh`  
  Linux-side bootstrap. Installs base packages, zsh/P10k, Node 24, Ollama, safe bounded Qwen model aliases, OpenClaw, and the explicit Ollama provider config.

- `verify_orchestrator_baseline_v1.sh`  
  Verifies the OpenClaw/Ollama baseline: bounded `qwen3.5:9b-4k`, GPU path, 4K context, gateway status, and dashboard-triggered inference.

- `configure_openclaw_discord_v1.sh`  
  Discord add-on. Installs/configures the official Discord plugin, stores the bot token via env reference, sets the Discord command owner, hardens `plugins.allow`, and restarts the gateway.

- `verify_openclaw_discord_v1.sh`  
  Verifies Discord config, token env presence, owner allowlist, active Discord channel, approved plugin allowlist, and optional manual Discord message path.

- `DISCORD_ADDON_PLAN_v1.md`  
  Notes and boundary documentation for the Discord add-on.

- `NEXT_CHATGPT_SESSION_BRIEF_v1.md`  
  Handoff brief for a new ChatGPT session.

## Clean install test from PowerShell

Open a fresh PowerShell prompt in the folder containing this package.

Use a unique distro name to avoid conflicts:

```powershell
cd "C:\Users\accou\Desktop\Repos\Powershell Scripts\orchestrator_wsl_openclaw_v1_package"

powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -RunBootstrap
```

If that named distro already exists and you intentionally want to replace only that named test distro:

```powershell
powershell -ExecutionPolicy Bypass -File .\init_orchestrator_wsl_v1.ps1 `
  -DistroName "Orchestrator-Ubuntu-22.04-RC2" `
  -ForceRecreate `
  -RunBootstrap
```

The script supports custom distro naming via `-DistroName`. It only unregisters the distro matching that exact name when `-ForceRecreate` is used.

## After baseline bootstrap completes

Enter the distro:

```powershell
wsl -d Orchestrator-Ubuntu-22.04-RC2
```

Inside WSL:

```bash
cd ~
bash ./verify_orchestrator_baseline_v1.sh
```

For the dashboard step, send:

```text
Reply with OK only.
```

Then return to the terminal and press Enter.

The baseline win condition is:

```text
qwen3.5:9b-4k    ...    100% GPU    4096
```

## Discord setup

Before Discord configuration, create/reset the bot token in the Discord Developer Portal. Do not paste the token into chat or logs.

Copy the Discord scripts into the distro if the package is not already available from `~/`:

```bash
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/configure_openclaw_discord_v1.sh ~/
cp /mnt/c/Users/accou/Desktop/Repos/'Powershell Scripts'/orchestrator_wsl_openclaw_v1_package/verify_openclaw_discord_v1.sh ~/
chmod +x ~/configure_openclaw_discord_v1.sh ~/verify_openclaw_discord_v1.sh
```

Run Discord configure with your Discord user ID:

```bash
bash ~/configure_openclaw_discord_v1.sh --owner-id 150398348518490112 --refresh-token
```

When prompted, paste the current valid Discord bot token. It will not echo.

Then verify:

```bash
bash ~/verify_openclaw_discord_v1.sh --owner-id 150398348518490112
```

If the verifier asks for the manual Discord test, DM the bot:

```text
Reply with OK only.
```

Then return to the terminal and press Enter.

Discord win condition:

```text
Discord default: enabled, configured, running, connected
plugins.allow approved: ['discord', 'ollama']
qwen3.5:9b-4k / 100% GPU / 4096 context
```

## Known boundaries

This v1 package proves infrastructure and transport. It does not yet solve agent identity/personality. The bot can still sound generic or "dumb" unless we add a separate identity/bootstrap layer for OpenClaw workspace files such as `SOUL.md`, `AGENTS.md`, and `USER.md`.

The likely next project is:

```text
OPENCLAW AGENT IDENTITY / ORCHESTRATOR BOOTSTRAP ADD-ON
```

That add-on should make the bot act like Roc, a useful Orchestrator-facing local command agent, instead of a generic assistant.

## Safety notes

- If a Discord bot token appears in logs, screenshots, files, or chat, treat it as burned and reset it.
- Heavy models remain opt-in. Do not automatically promote 30B+ models.
- `qwen3.5:9b-4k` is the safe default.
- `qwen3:30b-thinking-4k` is a gated opt-in test target only.
- `qwen3.6:35b` and heavy coder models caused hard lock/crash symptoms and should not be default.
- The PowerShell script grants passwordless sudo inside the disposable test distro so the install can run unattended. Remove later if converting a test distro into a long-lived environment:
  `sudo rm /etc/sudoers.d/90-orchestrator-bootstrap`
