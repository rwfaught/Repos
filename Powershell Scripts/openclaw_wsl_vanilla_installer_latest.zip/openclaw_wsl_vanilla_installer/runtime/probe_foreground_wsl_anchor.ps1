﻿param(
  [Parameter(Mandatory=$true)][string]$DistroName,
  [Parameter(Mandatory=$true)][string]$LinuxUser,
  [Parameter(Mandatory=$true)][string]$LogPath
)

$ErrorActionPreference = "Continue"

"$(Get-Date -Format o) foreground wrapper starting distro=$DistroName user=$LinuxUser" | Out-File -FilePath $LogPath -Encoding utf8 -Append

& wsl.exe --distribution $DistroName --user $LinuxUser --exec /bin/sleep 2147483647 >> $LogPath 2>&1

$ExitCode = $LASTEXITCODE
"$(Get-Date -Format o) foreground wrapper exiting wslExitCode=$ExitCode" | Out-File -FilePath $LogPath -Encoding utf8 -Append
exit $ExitCode
