﻿set -e

echo "=== BEFORE: OpenClaw version ==="
openclaw --version

echo ""
echo "=== UPDATE: Discord plugin ==="
openclaw plugins update discord

echo ""
echo "=== REINSTALL: gateway service definition ==="
openclaw gateway install --force

echo ""
echo "=== RELOAD/RESTART: gateway ==="
systemctl --user daemon-reload || true
openclaw gateway restart || systemctl --user restart openclaw-gateway.service

sleep 15

echo ""
echo "=== AFTER: OpenClaw version ==="
openclaw --version

echo ""
echo "=== AFTER: gateway status ==="
systemctl --user status openclaw-gateway.service --no-pager -l || true

echo ""
echo "=== AFTER: Discord channel probe ==="
openclaw channels status --probe </dev/null || true

echo ""
echo "=== AFTER: status deep update/channel/gateway lines ==="
openclaw status --deep </dev/null | grep -iE 'update|version|gateway service|gateway|channel|discord|plugin version drift' || true

echo ""
echo "=== AFTER: Discord plugin line ==="
openclaw plugins list </dev/null | grep -iE 'discord|@openclaw/discord' || true
