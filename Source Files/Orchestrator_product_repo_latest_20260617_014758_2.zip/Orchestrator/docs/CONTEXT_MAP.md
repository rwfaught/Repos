# Context Map

## Purpose And Authority

This file defines the Orchestrator product documentation context map and
language authority model. It exists to make document roles, bounded contexts,
owned language, and proof posture explicit for future coordinator re-entry and
worker handoff.

This file is authoritative for language/context architecture only. It does not
authorize implementation, cleanup, export, package creation, provider/model
execution, runtime behavior, platform behavior, or production task execution.

This file does not replace:

- `docs/TRACKS_AND_OPEN_THREADS.md`
- `docs/OPEN_THREAD_TRIAGE_PROTOCOL.md`
- `docs/PHASE_INDEX.md`
- `docs/ACTION_LOG.md`
- `docs/SOURCE_MANIFEST.md`
- `docs/CURRENT_SUCCESS_CRITERION.md`
- `docs/PROJECT_VISION.md`
- phase docs
- the external platform/OpenClaw memory capsule

Those documents and external authorities retain their own scope-specific
authority. This map explains how their language and contexts should be kept
separate.

## Document Authority Model

| Layer | Primary purpose | Authority docs/files | Notes |
| --- | --- | --- | --- |
| Constitutional direction | Defines what Orchestrator is trying to become and what growth must preserve. | `docs/PROJECT_VISION.md` | Long-range direction, not present capability proof. |
| Present success bar | Defines what a successful run means today. | `docs/CURRENT_SUCCESS_CRITERION.md` | Present-tense product bar, not a roadmap or phase authorization. |
| Coordinator/governance method | Defines ranking, approval, handoff, review, closure, re-entry discipline, open-thread triage, and startup-load discipline. | `docs/ORCHESTRATOR_METHOD.md`; `docs/ORCHESTRATOR_INTERACTION_MODEL.md`; `docs/STARTUP_BRIEF.md`; `docs/OPEN_THREAD_TRIAGE_PROTOCOL.md` | Governs process semantics, not runtime behavior. |
| Active product state/open threads | Preserves accepted track state, open threads, proof posture, triage status, and drift warnings. | `docs/TRACKS_AND_OPEN_THREADS.md`; `docs/OPEN_THREAD_TRIAGE_PROTOCOL.md` | Active coordination ledger and triage protocol; this context map does not complete its open threads. |
| Evidence/history stack | Records ordered phase history, action logs, source identity, artifact caveats, and accepted proof claims. | `docs/PHASE_INDEX.md`; `docs/ACTION_LOG.md`; `docs/SOURCE_MANIFEST.md`; phase docs | Evidence/history authorities; not mandatory full-load startup payloads unless the boundary requires phase history, source registration, proof, or reconciliation. |
| Language/context architecture | Defines bounded contexts, owned terms, and do-not-confuse rules for docs. | `docs/CONTEXT_MAP.md` | Clarifies language authority only; it does not clean up historical docs by itself. |

## Bounded Context Map

### Product Governance Context

Purpose: preserve Orchestrator as the governing layer for AI-assisted work,
including ranking, approval gates, role boundaries, closure, and re-entry.

Owned language: Orchestrator, coordinator, Roger/operator, Relay, worker, NBM,
boundary, open thread, caveat.

Authority docs/files:

- `docs/PROJECT_VISION.md`
- `docs/ORCHESTRATOR_METHOD.md`
- `docs/ORCHESTRATOR_INTERACTION_MODEL.md`
- `docs/STARTUP_BRIEF.md`
- `docs/TRACKS_AND_OPEN_THREADS.md`
- `docs/OPEN_THREAD_TRIAGE_PROTOCOL.md`

Non-authority / do-not-confuse warnings:

- Governance health is not product execution proof.
- Worker PASS is not coordinator artifact acceptance.
- Relay construction is not worker execution.
- Authorization is not execution.
- This context map is not a cleanup-completion record.
- Startup-load discipline keeps append-heavy evidence/history docs on demand
  unless the boundary requires them.

Current proof posture: governance and interaction protocols are documented;
Phase 102 locally proved the durable cross-track ledger; Phase 104 locally
proves only the documentation language/context map.

### Startup Load Classes

- `ALWAYS_READ_CONTROL`: small docs needed for role, protocol, and current
  orientation.
- `CURRENT_STATE`: docs used to understand active product state and open
  threads.
- `ON_DEMAND_EVIDENCE`: append-heavy docs such as `ACTION_LOG.md`,
  `SOURCE_MANIFEST.md`, `PHASE_INDEX.md`, phase docs, and historical design
  docs. Read when the boundary requires evidence, phase history, source
  registration, proof, or reconciliation.
- `EXTERNAL_TRACK_PACKAGE`: platform/OpenClaw/Hermes/model/RAG package docs.
  Read only when that track or an integration boundary is in scope.

### Request Intake / Routing Context

Purpose: classify human objectives into bounded request types and validate
structured route envelopes before downstream capability use is admitted.

Owned language: route membrane, route envelope, route admission, request type,
capability, substrate, provider/model.

Authority docs/files:

- `docs/PROJECT_VISION.md`
- `docs/ORCHESTRATOR_INTERACTION_MODEL.md`
- `docs/PHASE_103.md`
- `orchestrator/request_routing.py`
- `tests/test_phase_103_domain_general_request_routing_contract.py`
- `docs/TRACKS_AND_OPEN_THREADS.md`

Non-authority / do-not-confuse warnings:

- Route-envelope validation is not request execution.
- Route admission is not live model routing.
- Capability labels are not proof that a capability is implemented.
- Substrate description must not become provider/model selection.
- Coding remains one request route, not the product identity.

Current proof posture: Phase 103 validates structured route envelopes only. It
does not implement live route proposal, model routing, RAG/local-document
lookup, reminders, scheduling, web lookup, autonomous writeback, or production
task execution.

## Task Risk Routing Doctrine

Task risk routing is a human-facing control doctrine for deciding what kind of
route, permission, confirmation, substrate, validation, and stop condition a
request requires before any downstream work is admitted.

| Task risk | Route class | Permissions | Confirmation burden | Allowed substrate | Validation burden | Stop conditions |
| --- | --- | --- | --- | --- | --- | --- |
| Simple answer or report-only request | `general_answer` or report-only lane | Answer only; no mutation, scheduling, retrieval, or provider execution claim | Low, unless facts are stale or consequential | Coordinator/report-only surface | Cite or state basis when needed; preserve caveats | Missing facts, high-stakes uncertainty, or requested capability outside report-only scope |
| Local-document lookup or RAG-style lookup | `local_document_lookup` | Read/search declared local document sources only | Confirm source set when ambiguous or sensitive | Document lookup surface only, once implemented | Source-grounded answer with inspectable citations or evidence paths | Missing source authority, stale-source risk, or requested mutation/execution |
| Reminder or scheduler request | `reminder_request` | Schedule only after explicit confirmation | Explicit operator confirmation required before persistence or scheduling | Scheduler/reminder surface only, once implemented | Confirm time, recurrence, target, notification semantics, and persistence | Ambiguous time, missing confirmation, or request to execute non-reminder work |
| Coding task | `coding_task` | Mutation only with explicit boundary and declared file scope | Explicit operator authorization through a bounded worker packet | Coding worker or authorized coding spine; substrate must not be smuggled through route text | Worker validation plus coordinator review; local PASS is not acceptance | Unclear scope, undeclared files, conflicting evidence, or mutation beyond packet |
| File operation | `file_operation` | Read/write/move/delete only if explicitly authorized and scoped | Explicit confirmation proportional to destructive or broad impact | Bounded file-operation surface or worker packet | Path, scope, and effect evidence; no hidden adjacent cleanup | Unsafe paths, broad scope, deletion/archive ambiguity, or missing backup/approval where required |
| Platform, substrate, runtime, provider, or model work | External or platform/substrate track unless product boundary explicitly crosses tracks | No product-side execution by default | Separate boundary with platform authority and fresh operator evidence | Platform package, provider, model, or runtime surface only under explicit crossing boundary | Fresh proof appropriate to the external track; no historical-runtime inference | Boundary lacks crossing authority, current runtime proof is missing, or product/platform authority conflicts |
| Unsupported, requires connector, or needs clarification | `unsupported` or `needs_clarification` | No capability enabled | Clarify or block before downstream work | None until admitted | Explain missing connector, authority, scope, or capability | Connector unavailable, request type unclear, required authority missing, or permissions contradictory |

Standing routing rules:

- Route validation is not execution.
- Authorization is not execution.
- Provider/model availability is not route correctness.
- Capability labels are not implementation proof.
- Mutation requires explicit authorization and declared scope.
- Scheduler/reminder lanes require explicit confirmation.
- Platform/substrate/runtime work remains separate unless a boundary explicitly
  authorizes crossing tracks.

### Coding Spine Context

Purpose: govern bounded coding/file-mutation work through proposal,
authorization, apply evidence, verification review, and explicit finalization.

Owned language: filesystem mutation, report-only, patch proposal, operator
apply authorization, apply result, causal change, finalization, completion
gate.

Authority docs/files:

- `docs/CURRENT_SUCCESS_CRITERION.md`
- `docs/PHASE_95.md` through `docs/PHASE_101.md`
- `docs/PHASE_INDEX.md`
- coding-spine source/test files listed in phase docs
- `docs/TRACKS_AND_OPEN_THREADS.md`

Non-authority / do-not-confuse warnings:

- Component PASS markers are not broad semantic correctness proof.
- Patch proposal is not patch application.
- Apply evidence is not full task success.
- Finalization does not prove production readiness.
- Autonomous writeback remains unproven.

Current proof posture: Phase 97 through Phase 101 components are locally
source/test/docs-proven and the Phase 101 product ZIP is accepted as the last
uploaded artifact in inspected repo docs. Integrated production workflow
readiness is not proven.

### Evidence / Artifact Proof Context

Purpose: preserve the distinction between source state, local proof, export
proof, upload proof, non-proof, and caveated historical records.

Owned language: source state, export proof, upload proof, non-proof, caveat,
artifact proof, SHA-256, accepted artifact, fresh operator output.

Authority docs/files:

- `docs/SOURCE_MANIFEST.md`
- `docs/ACTION_LOG.md`
- `docs/PHASE_INDEX.md`
- phase docs
- external operator export/upload logs when supplied
- `docs/TRACKS_AND_OPEN_THREADS.md`

Non-authority / do-not-confuse warnings:

- In-repo text cannot prove the hash of a later export.
- Export PASS is not upload PASS.
- Local source/test/docs proof is not artifact proof.
- Historical artifact records are not automatically current source truth.
- Memory or handoff text is not proof without reconciliation.

Current proof posture: inspected repo docs preserve Phase 101 as the accepted
uploaded artifact and state Phase 102 was not exported/uploaded. Phase 103 is
locally source/test/docs-proven only and not exported/uploaded.

### Platform / Substrate Context

Purpose: keep platform/runtime/installer/OpenClaw/Ollama/Discord/bridge/adapter
claims separate from product documentation and source-state claims.

Owned language: platform, substrate, provider/model, OpenClaw, Ollama, WSL,
Discord, bridge, adapter, installer, external memory capsule.

Authority docs/files:

- external platform/OpenClaw memory capsule
- platform package docs, when explicitly in scope
- product-side platform references in `docs/SOURCE_MANIFEST.md` and
  `docs/TRACKS_AND_OPEN_THREADS.md`

Non-authority / do-not-confuse warnings:

- The platform installer is not the product repo.
- Historical runtime proof is not current runtime truth.
- Product docs may reference platform separation without making live platform
  claims.
- Provider/model availability is not routing proof or mutation proof.

Current proof posture: Phase 104 performs no platform inspection beyond product
docs and makes no current runtime, installer, provider/model, OpenClaw,
Discord, bridge, adapter, WSL, or platform behavior claim.

## Ubiquitous Language

| Term | Definition |
| --- | --- |
| Orchestrator | The governing layer for AI-assisted work, intended to preserve boundedness, inspectability, explicit state, reviewability, diagnosable failure, and operator judgment. |
| coordinator | The governance role that ranks, scopes, packages, reviews, ratifies, and preserves context; not the worker executor. |
| Roger/operator | The owner/operator authority who approves direction, relays worker packets, and accepts or rejects results. |
| Relay | The human-mediated command or prompt transfer layer; relay construction is not execution proof. |
| worker | A bounded implementation role that inspects and mutates only within an authorized packet, then reports evidence. |
| NBM | Next best move: the coordinator-ranked immediate intervention, justified against the present success bar and constitutional direction. |
| boundary | The explicit in-scope/out-of-scope membrane for a phase, fix, or document mutation. |
| route membrane | The governance boundary that decides whether a structured route proposal is admissible before downstream capability use. |
| route envelope | A structured object containing request type, confidence, capabilities, permissions, caveats, and recommended next action for route validation. |
| route admission | The validation outcome for a route envelope: accepted, needs clarification, or rejected. |
| request type | The domain-general category assigned to a proposed request, such as general answer, local document lookup, reminder request, coding task, file operation, planning request, research request, creative generation, unsupported, or needs clarification. |
| capability | A named ability needed by a route or task; a capability label is not proof that the capability exists or executed. |
| substrate | The underlying execution or support surface, such as worker, provider, model, platform, or connector; substrate naming must not bypass route or operator gates. |
| provider/model | A concrete AI or execution provider/model surface; provider/model existence is not proof of route execution, semantic correctness, or mutation authority. |
| source state | The contents of the product repo at a point in time after local mutation; source state is not the same as an exported or uploaded artifact. |
| export proof | Fresh evidence that a product artifact was created from a source state and has observed path, hash, size, entries, and contents. |
| upload proof | Fresh evidence that an exported artifact was uploaded and verified in the receiving context. |
| non-proof | A claim, marker, note, or memory that does not establish the behavior or artifact identity it might appear to imply. |
| caveat | A preserved limitation that bounds what a proof or source claim actually establishes. |
| open thread | A durable unresolved question, obligation, or risk that must remain visible until a future boundary explicitly resolves it with evidence. |

## Active-Vs-Historical Document Separation

Active governing documents define current direction, current success bar,
current process semantics, active track state, and language architecture.
Historical phase docs and logs preserve what was done, what was proven, and
what was not proven at the time.

Rules:

1. Do not rewrite historical phase records to make later state look cleaner.
2. Do not treat an older phase doc's local proof as current artifact proof.
3. Do not treat the existence of this context map as redundancy cleanup.
4. Do not collapse active open threads into historical caveats.
5. When sources conflict, current repo evidence and fresh artifact/operator
   proof outrank conversational memory and handoff claims.

## Artifact-Proof Hygiene Rules

1. Source-state claims, export proof, and upload proof must remain separate.
2. A ZIP cannot self-prove its own final post-edit hash from inside the same
   source mutation that changes the ZIP contents.
3. Artifact hashes require fresh external observation of the produced artifact.
4. Export PASS must not be reported as upload PASS.
5. Upload acceptance must state the observed artifact identity and verification
   basis.
6. Local docs/control proof must not be described as source/test proof unless
   source/tests were actually changed and validated.
7. Worker-reported PASS markers remain worker proof until coordinator
   ratification or artifact acceptance occurs.

## Phase 102 Artifact-Proof Conflict

This conflict is explicitly preserved as an open reconciliation thread:

- A supplied handoff may claim Phase 102 upload hash
  `F5A53C67100F95744E20E25ED5A48A244E4D08C021E848463AAF3BE2A7D23CA6`.
- Inspected repo docs preserve Phase 101 as the accepted uploaded artifact and
  state Phase 102 was not exported/uploaded.
- Do not resolve this conflict without fresh artifact proof.

Until fresh proof is supplied, product docs should preserve the inspected repo
position: Phase 101 is the accepted uploaded artifact, and Phase 102 is local
docs/control source state only.

## Phase 103 Routing Boundary

Phase 103 validates structured route envelopes only.

It does not implement:

- live route proposal
- model routing
- RAG/local-document lookup
- reminders
- scheduling
- web lookup
- autonomous writeback
- production task execution

The Phase 103 contract may name request types, required route-envelope fields,
permissions, capabilities, caveats, and no-activity flags. It does not execute
those capabilities or prove that any future route is productized.
